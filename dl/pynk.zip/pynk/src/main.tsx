import { createRoot } from 'react-dom/client'
import App from './App'
import './styles/global.css'

// No StrictMode by choice: this page manages a persistent WebGL context,
// Lenis and ScrollTrigger singletons; dev double-mounting only adds noise.
createRoot(document.getElementById('root')!).render(<App />)
