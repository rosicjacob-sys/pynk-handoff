/** dataLayer stubs — swap for GA4/Segment by consuming window.dataLayer. */

type EventName = 'view_item' | 'add_to_cart' | 'begin_checkout'

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[]
  }
}

export function track(event: EventName, payload: Record<string, unknown> = {}) {
  try {
    window.dataLayer = window.dataLayer || []
    window.dataLayer.push({ event, ...payload })
    if (import.meta.env.DEV) console.info('[analytics]', event, payload)
  } catch {
    /* analytics must never break the store */
  }
}
