import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { prefersReducedMotion } from './motion'

gsap.registerPlugin(ScrollTrigger)

if (import.meta.env.DEV && typeof window !== 'undefined') {
  ;(window as unknown as Record<string, unknown>).__ST = ScrollTrigger
}

/** Smoothed signed scroll velocity, shared with shaders + kinetic type. */
export const scrollState = {
  velocity: 0, // raw lenis velocity (px/frame-ish)
  smooth: 0, // low-passed
  norm: 0, // smooth, clamped to [-1, 1]
}

let lenis: Lenis | null = null
let tickerFn: ((t: number) => void) | null = null

export function initSmoothScroll(): Lenis | null {
  if (prefersReducedMotion() || lenis) return lenis
  lenis = new Lenis({
    duration: 1.15,
    smoothWheel: true,
    autoRaf: false,
  })
  lenis.on('scroll', ScrollTrigger.update)
  // Fallback for scroll sources Lenis doesn't mediate (scrollbar drags,
  // keyboard paging, programmatic scrollTo): keep triggers in sync.
  window.addEventListener('scroll', ScrollTrigger.update, { passive: true })
  if (import.meta.env.DEV) {
    ;(window as unknown as Record<string, unknown>).__lenis = lenis
  }
  tickerFn = (t: number) => {
    lenis?.raf(t * 1000)
    const v = lenis ? lenis.velocity : 0
    scrollState.velocity = v
    scrollState.smooth += (v - scrollState.smooth) * 0.09
    scrollState.norm = Math.max(-1, Math.min(1, scrollState.smooth / 30))
  }
  gsap.ticker.add(tickerFn)
  gsap.ticker.lagSmoothing(0)
  return lenis
}

export function destroySmoothScroll() {
  if (tickerFn) gsap.ticker.remove(tickerFn)
  tickerFn = null
  window.removeEventListener('scroll', ScrollTrigger.update)
  lenis?.destroy()
  lenis = null
}

export const getLenis = () => lenis

/** Current scroll top that works with or without Lenis. */
export const getScrollY = () =>
  lenis ? lenis.scroll : window.scrollY || document.documentElement.scrollTop

export function scrollToEl(target: string | HTMLElement) {
  if (lenis) {
    lenis.scrollTo(target, { offset: -20, duration: 1.4 })
  } else {
    const el =
      typeof target === 'string'
        ? document.querySelector<HTMLElement>(target)
        : target
    el?.scrollIntoView({ behavior: 'auto', block: 'start' })
  }
}

export { gsap, ScrollTrigger }
