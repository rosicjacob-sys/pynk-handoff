import gsap from 'gsap'
import { prefersReducedMotion } from './motion'

/**
 * The conversion dopamine hit: a pink pill arcs from the buy button into the
 * cart icon. Pure transform animation on a throwaway fixed element.
 */
export function flyToCart(fromEl: HTMLElement, toEl: HTMLElement) {
  if (prefersReducedMotion()) return

  const a = fromEl.getBoundingClientRect()
  const b = toEl.getBoundingClientRect()
  const start = { x: a.left + a.width / 2, y: a.top + a.height / 2 }
  const end = { x: b.left + b.width / 2, y: b.top + b.height / 2 }
  // control point above the midpoint -> a lofted arc
  const ctrl = {
    x: (start.x + end.x) / 2,
    y: Math.min(start.y, end.y) - 140,
  }

  const pill = document.createElement('div')
  pill.className = 'fly-pill'
  pill.style.left = '0px'
  pill.style.top = '0px'
  document.body.appendChild(pill)

  const state = { t: 0 }
  gsap.to(state, {
    t: 1,
    duration: 0.8,
    ease: 'power2.inOut',
    onUpdate: () => {
      const t = state.t
      const mt = 1 - t
      const x = mt * mt * start.x + 2 * mt * t * ctrl.x + t * t * end.x
      const y = mt * mt * start.y + 2 * mt * t * ctrl.y + t * t * end.y
      const scale = 1 - t * 0.55
      const rot = t * 260
      pill.style.transform = `translate3d(${x - 22}px, ${y - 9.5}px, 0) rotate(${rot}deg) scale(${scale})`
    },
    onComplete: () => {
      gsap.to(pill, {
        opacity: 0,
        scale: 0.2,
        duration: 0.18,
        ease: 'power2.in',
        onComplete: () => pill.remove(),
      })
    },
  })
}
