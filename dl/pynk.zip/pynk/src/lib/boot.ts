/**
 * Boot gate: reveals wait on the loader so they don't fire under the overlay.
 * Hard wall-clock cap — a throttled rAF can never hang boot.
 */

let resolveBoot: () => void
let booted = false

export const bootDone: Promise<void> = new Promise((res) => {
  resolveBoot = () => {
    if (booted) return
    booted = true
    res()
  }
})

export const isBooted = () => booted

export function finishBoot() {
  resolveBoot()
}

/** Absolute ceiling — even if the loader component never mounts. */
if (typeof window !== 'undefined') {
  window.setTimeout(() => finishBoot(), 2500)
}
