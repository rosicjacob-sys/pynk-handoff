/** Central media/motion capability flags. Evaluated once per load. */

export const prefersReducedMotion = (): boolean =>
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

export const isFinePointer = (): boolean =>
  typeof window !== 'undefined' && window.matchMedia('(pointer: fine)').matches

export const isDesktop = (): boolean =>
  typeof window !== 'undefined' && window.matchMedia('(min-width: 800px)').matches

/** Shared wall-clock failsafe: run `fn` after `ms` unless cancelled. */
export function failsafe(fn: () => void, ms = 3500): () => void {
  const id = window.setTimeout(fn, ms)
  return () => window.clearTimeout(id)
}
