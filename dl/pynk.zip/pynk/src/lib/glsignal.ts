/** WebGL failure signal — flips the page to the static pink fallback. */
export const glStatus = { failed: false }

export function reportGlFailure() {
  if (glStatus.failed) return
  glStatus.failed = true
  window.dispatchEvent(new Event('pynk:glfail'))
}
