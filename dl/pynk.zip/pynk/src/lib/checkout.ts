import { track } from './analytics'
import type { CartItem } from '../store/cart'
import { VARIANTS } from '../data/product'

/**
 * Swappable checkout. Wire Shopify Storefront / Stripe Checkout / Snipcart by
 * calling setCheckoutProvider() with an adapter — nothing else changes.
 */
export type CheckoutResult = { ok: boolean; message?: string }
export type CheckoutProvider = (items: CartItem[]) => Promise<CheckoutResult>

const mockProvider: CheckoutProvider = async () => {
  // Demo adapter: simulates a redirect handshake to a hosted checkout.
  await new Promise((r) => setTimeout(r, 700))
  return {
    ok: true,
    message: 'Demo checkout — connect Shopify, Stripe or Snipcart via setCheckoutProvider().',
  }
}

let provider: CheckoutProvider = mockProvider

export function setCheckoutProvider(p: CheckoutProvider) {
  provider = p
}

export async function checkout(items: CartItem[]): Promise<CheckoutResult> {
  const value = items.reduce(
    (sum, it) => sum + VARIANTS[it.variantId].price * it.qty,
    0,
  )
  track('begin_checkout', {
    currency: 'USD',
    value: Number(value.toFixed(2)),
    items: items.map((it) => ({ item_id: it.variantId, quantity: it.qty })),
  })
  return provider(items)
}
