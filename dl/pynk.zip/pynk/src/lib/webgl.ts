/** WebGL capability probe + coarse device tier. 0 = none, 1 = light, 2 = full. */

export type GpuTier = 0 | 1 | 2

let cached: GpuTier | null = null

export function gpuTier(): GpuTier {
  if (cached !== null) return cached
  try {
    const canvas = document.createElement('canvas')
    const gl =
      canvas.getContext('webgl2') ||
      canvas.getContext('webgl') ||
      canvas.getContext('experimental-webgl')
    if (!gl) {
      cached = 0
      return cached
    }
    const coarse = window.matchMedia('(pointer: coarse)').matches
    const small = window.innerWidth < 800
    const lowCores = (navigator.hardwareConcurrency ?? 8) <= 4
    cached = coarse || small || lowCores ? 1 : 2
    const lose = (gl as WebGLRenderingContext).getExtension('WEBGL_lose_context')
    lose?.loseContext()
    return cached
  } catch {
    cached = 0
    return cached
  }
}

/** Granule instance budget per tier. */
export const granuleCount = (tier: GpuTier) => (tier >= 2 ? 2600 : 1200)
