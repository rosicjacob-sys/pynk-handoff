import * as THREE from 'three'
import { stage, NODE_RADIUS_VMIN } from '../store/stage'
import { getScrollY } from '../lib/scroll'

/**
 * The single source of truth for the pill's journey. DOM ScrollTriggers write
 * section progress into `stage`; this derives one continuous pose per frame.
 * Pure math, zero allocation.
 */
export interface FrameState {
  pos: THREE.Vector3
  scale: number
  /** 0 closed capsule … 1 halves fully apart */
  split: number
  halvesAlpha: number
  /** granule morph weights (sum to 1) */
  wHome: number
  wSwirl: number
  wNode: number
  wStream: number
  granuleAlpha: number
  /** ingredient-ring radius in world units */
  nodeR: number
  wallT: number
  convergeT: number
  glow: number
  buy: THREE.Vector3
  intro: number
  isMobile: boolean
  wu: number
  hu: number
}

export const frame: FrameState = {
  pos: new THREE.Vector3(0, 0, 0),
  scale: 0.001,
  split: 0,
  halvesAlpha: 1,
  wHome: 1,
  wSwirl: 0,
  wNode: 0,
  wStream: 0,
  granuleAlpha: 0,
  nodeR: 2,
  wallT: 0,
  convergeT: 0,
  glow: 0.5,
  buy: new THREE.Vector3(),
  intro: 0,
  isMobile: false,
  wu: 10,
  hu: 6,
}

if (import.meta.env.DEV && typeof window !== 'undefined') {
  ;(window as unknown as Record<string, unknown>).__frame = frame
}

const clamp01 = (x: number) => Math.min(1, Math.max(0, x))
const sm = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a))
  return t * t * (3 - 2 * t)
}
const lerp = THREE.MathUtils.lerp
const backOut = (t: number) => {
  const c = 1.70158
  const u = t - 1
  return 1 + (c + 1) * u * u * u + c * u * u
}

export function computeFrame(
  dt: number,
  wu: number,
  hu: number,
  vwPx: number,
  vhPx: number,
) {
  const s = stage
  const isMobile = vwPx < 800
  frame.isMobile = isMobile
  frame.wu = wu
  frame.hu = hu
  frame.intro = clamp01(frame.intro + dt / 1.2)
  frame.nodeR = Math.min(wu, hu) * NODE_RADIUS_VMIN * (isMobile ? 0.82 : 1)

  // ---------- buy anchor (doc px -> world units, no layout reads) ----------
  if (s.hasBuyAnchor) {
    const sx = s.buyAnchorDocX
    const sy = s.buyAnchorDocY - getScrollY()
    frame.buy.set((sx / vwPx - 0.5) * wu, (0.5 - sy / vhPx) * hu, 0)
  } else {
    frame.buy.set(isMobile ? 0 : -wu * 0.2, 0, 0)
  }

  // ---------- position / scale chain (sequential section blends) ----------
  let x = isMobile ? 0 : wu * 0.23
  let y = isMobile ? -hu * 0.24 : -hu * 0.05
  let sc = isMobile ? 0.58 : 1

  const sciIn = sm(0, 0.14, s.scienceP)
  x = lerp(x, 0, sciIn)
  y = lerp(y, isMobile ? -hu * 0.18 : -hu * 0.08, sciIn)
  sc = lerp(sc, isMobile ? 0.6 : 0.88, sciIn)

  const howIn = sm(0, 0.22, s.howP)
  x = lerp(x, isMobile ? 0 : wu * 0.25, howIn)
  y = lerp(y, isMobile ? -hu * 0.3 : 0, howIn)
  sc = lerp(sc, isMobile ? 0.4 : 0.6, howIn)

  const prIn = sm(0, 0.3, s.proofP)
  x = lerp(x, wu * 0.36, prIn)
  y = lerp(y, hu * 0.26, prIn)
  sc = lerp(sc, 0.4, prIn)

  const buyIn = sm(0.04, 0.6, s.buyP)
  x = lerp(x, frame.buy.x + (isMobile ? wu * 0.2 : wu * 0.09), buyIn)
  y = lerp(y, frame.buy.y + hu * 0.12, buyIn)
  sc = lerp(sc, isMobile ? 0.42 : 0.6, buyIn)

  const out = sm(0.08, 0.55, s.outroP)
  sc *= 1 - out

  sc *= backOut(frame.intro)

  // Damp for cream on top of the scrub smoothing.
  const l = 8
  frame.pos.x = THREE.MathUtils.damp(frame.pos.x, x, l, dt)
  frame.pos.y = THREE.MathUtils.damp(frame.pos.y, y, l, dt)
  frame.scale = THREE.MathUtils.damp(frame.scale, Math.max(0.0001, sc), l, dt)

  // ---------- split + shell visibility ----------
  const open = sm(0.13, 0.3, s.scienceP)
  const close = 1 - sm(0.5, 0.86, s.howP)
  frame.split = open * close

  const gone = sm(0.44, 0.68, s.scienceP)
  const back = sm(0.36, 0.58, s.howP)
  frame.halvesAlpha = 1 - gone * (1 - back)

  // ---------- granule morph weights ----------
  const swirlIn = sm(0.16, 0.33, s.scienceP)
  const toNode = sm(0.4, 0.6, s.scienceP)
  const toStream = sm(0.04, 0.34, s.howP)
  const toHome = sm(0.46, 0.78, s.howP)

  const wSwirl = swirlIn * (1 - toNode) * (1 - toStream) * (1 - toHome)
  const wNode = toNode * (1 - toStream) * (1 - toHome)
  const wStream = toStream * (1 - toHome)
  frame.wSwirl = wSwirl
  frame.wNode = wNode
  frame.wStream = wStream
  frame.wHome = clamp01(1 - wSwirl - wNode - wStream)

  frame.granuleAlpha =
    sm(0.15, 0.24, s.scienceP) * (1 - sm(0.7, 0.9, s.howP))

  // ---------- wall / converge / glow ----------
  frame.wallT = sm(0.03, 0.72, s.proofP)
  frame.convergeT = sm(0.04, 0.68, s.buyP)
  frame.glow = clamp01(0.5 + sciIn * 0.4 + buyIn * 0.25 - out * 1.2)
}
