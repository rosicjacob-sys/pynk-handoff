import { useMemo, useRef, useEffect } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { frame } from './choreography'
import { NODE_ANGLES } from '../store/stage'
import { scrollState } from '../lib/scroll'
import { gpuTier, granuleCount } from '../lib/webgl'
import { perfState } from './palette'

/**
 * GPU-instanced micro-granules. All morph targets (capsule interior, swirl,
 * ingredient nodes, dissolve stream) are computed in the vertex shader from
 * static attributes — zero per-frame buffer writes, zero allocation.
 */

const vertex = /* glsl */ `
  uniform float uTime;
  uniform vec4 uW;        // home, swirl, node, stream
  uniform float uNodeR;   // local units
  uniform float uStreamH; // local units
  uniform float uSize;
  uniform float uVel;
  uniform float uSplit;
  attribute vec3 aHome;
  attribute vec3 aDir;
  attribute vec4 aSeed;
  varying float vMix;
  varying float vShade;

  float hash(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
  }
  float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash(i);
    float n100 = hash(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash(i + vec3(1.0, 1.0, 1.0));
    return mix(
      mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
      mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y),
      f.z
    );
  }
  float fbm(vec3 p) {
    return vnoise(p) * 0.65 + vnoise(p * 2.35 + 11.7) * 0.35;
  }

  void main() {
    float t = uTime;

    // HOME: packed inside the capsule, following the halves as they part
    vec3 homeP = aHome;
    homeP.y += sign(aHome.y) * uSplit * 0.6;

    // SWIRL: domain-warped orbital cloud
    float ang = aSeed.x * 6.28318 + t * (0.3 + aSeed.y * 0.5) * (0.7 + abs(uVel) * 0.9);
    float rad = uNodeR * (0.22 + aSeed.z * 0.78);
    vec3 swirlP = vec3(
      cos(ang) * rad,
      sin(ang * 0.83 + aSeed.w * 4.0) * rad * 0.5,
      sin(ang) * rad * 0.4
    );
    vec3 q = aHome * 1.4 + t * 0.16;
    vec3 warp = vec3(fbm(q), fbm(q + 7.3), fbm(q + 19.1)) - 0.5;
    swirlP += warp * uNodeR * (0.5 + abs(uVel) * 0.35);

    // NODE: tight ingredient clusters on the shared pentagon ring
    vec3 nodeP = aDir * uNodeR;
    nodeP.x += (fbm(nodeP * 2.0 + t * 0.3) - 0.5) * uNodeR * 0.1;
    nodeP.y += (fbm(nodeP * 2.0 + 31.0 + t * 0.27) - 0.5) * uNodeR * 0.1;

    // STREAM: dissolving powder pour, wrapping fall
    float fall = fract(aSeed.y * 7.31 + t * 0.17);
    vec3 streamP = vec3(
      (aSeed.x - 0.5) * uNodeR * (0.5 + fall * 1.3) +
        (fbm(vec3(aSeed.x * 43.0, fall * 2.5, t * 0.22)) - 0.5) * uNodeR * 0.7,
      uStreamH * (0.55 - fall * 1.1),
      (aSeed.w - 0.5) * uNodeR * 0.5
    );

    vec3 p = homeP * uW.x + swirlP * uW.y + nodeP * uW.z + streamP * uW.w;

    float size = uSize * (0.55 + aSeed.z * 0.95) * (1.0 + uW.z * 0.7);
    vec3 transformed = p + position * size;
    vec4 mv = modelViewMatrix * vec4(transformed, 1.0);
    gl_Position = projectionMatrix * mv;

    vShade = 0.6 + 0.4 * max(0.0, dot(normalize(normalMatrix * normal), normalize(vec3(0.35, 0.7, 0.6))));
    vMix = aSeed.w;
  }
`

const fragment = /* glsl */ `
  precision highp float;
  uniform float uAlpha;
  varying float vMix;
  varying float vShade;
  void main() {
    vec3 cGlow = vec3(1.0, 0.372, 0.659);  /* magenta glow */
    vec3 cRoyal = vec3(1.0, 0.18, 0.533);  /* royal pink   */
    vec3 cDeep = vec3(0.769, 0.071, 0.42); /* deep pink    */
    vec3 col = mix(cGlow, cRoyal, vMix);
    col = mix(col, cDeep, smoothstep(0.72, 1.0, vMix) * 0.65);
    gl_FragColor = vec4(col * (vShade * 1.22), uAlpha);
  }
`

export default function Granules() {
  const meshRef = useRef<THREE.Mesh>(null!)
  const count = useMemo(() => granuleCount(gpuTier()), [])

  const geometry = useMemo(() => {
    const base = new THREE.IcosahedronGeometry(0.021, 0)
    const geo = new THREE.InstancedBufferGeometry()
    geo.index = base.index
    geo.attributes.position = base.attributes.position
    geo.attributes.normal = base.attributes.normal
    geo.instanceCount = count

    const home = new Float32Array(count * 3)
    const dir = new Float32Array(count * 3)
    const seed = new Float32Array(count * 4)

    // rejection-sample the capsule interior (R=0.55 inner, half length 0.66)
    const cr = 0.52
    const cl = 0.62
    for (let i = 0; i < count; i++) {
      let px = 0
      let py = 0
      let pz = 0
      for (let tries = 0; tries < 20; tries++) {
        px = (Math.random() * 2 - 1) * cr
        py = (Math.random() * 2 - 1) * (cl + cr)
        pz = (Math.random() * 2 - 1) * cr
        const cy = Math.max(0, Math.abs(py) - cl)
        if (px * px + cy * cy + pz * pz < cr * cr) break
      }
      home[i * 3] = px
      home[i * 3 + 1] = py
      home[i * 3 + 2] = pz

      const k = i % NODE_ANGLES.length
      const spread = 0.13
      const gx = (Math.random() + Math.random() + Math.random() - 1.5) * spread
      const gy = (Math.random() + Math.random() + Math.random() - 1.5) * spread
      dir[i * 3] = Math.cos(NODE_ANGLES[k]) + gx
      dir[i * 3 + 1] = Math.sin(NODE_ANGLES[k]) + gy
      dir[i * 3 + 2] = (Math.random() - 0.5) * 0.18

      seed[i * 4] = Math.random()
      seed[i * 4 + 1] = Math.random()
      seed[i * 4 + 2] = Math.random()
      seed[i * 4 + 3] = Math.random()
    }

    geo.setAttribute('aHome', new THREE.InstancedBufferAttribute(home, 3))
    geo.setAttribute('aDir', new THREE.InstancedBufferAttribute(dir, 3))
    geo.setAttribute('aSeed', new THREE.InstancedBufferAttribute(seed, 4))
    return geo
  }, [count])

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: vertex,
        fragmentShader: fragment,
        uniforms: {
          uTime: { value: 0 },
          uW: { value: new THREE.Vector4(1, 0, 0, 0) },
          uNodeR: { value: 2 },
          uStreamH: { value: 6 },
          uSize: { value: 1 },
          uVel: { value: 0 },
          uSplit: { value: 0 },
          uAlpha: { value: 0 },
        },
        transparent: true,
        depthWrite: false,
      }),
    [],
  )

  useEffect(() => {
    return () => {
      geometry.dispose()
      material.dispose()
    }
  }, [geometry, material])

  useFrame((state) => {
    const mesh = meshRef.current
    if (!mesh) return
    const active = frame.granuleAlpha > 0.004 && frame.scale > 0.002
    mesh.visible = active
    if (!active) return

    mesh.position.set(frame.pos.x, frame.pos.y, 0)
    mesh.scale.setScalar(frame.scale)

    const u = material.uniforms
    u.uTime.value = state.clock.elapsedTime
    u.uW.value.set(frame.wHome, frame.wSwirl, frame.wNode, frame.wStream)
    u.uNodeR.value = frame.nodeR / frame.scale
    u.uStreamH.value = frame.hu / frame.scale
    u.uVel.value = scrollState.norm
    u.uSplit.value = frame.split
    u.uAlpha.value = frame.granuleAlpha

    // adaptive quality: shrink the live instance window under load
    geometry.instanceCount = Math.max(200, Math.floor(count * perfState.q))
  })

  return (
    <mesh
      ref={meshRef}
      geometry={geometry}
      material={material}
      frustumCulled={false}
      visible={false}
    />
  )
}
