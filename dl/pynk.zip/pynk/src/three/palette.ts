export const PINK_ROYAL = '#ff2e88'
export const PINK_DEEP = '#c4126b'
export const MAGENTA_GLOW = '#ff5fa8'
export const BLUSH = '#ffe3f0'

/** Adaptive quality knob written by PerformanceMonitor, read per-frame. */
export const perfState = { q: 1 }
