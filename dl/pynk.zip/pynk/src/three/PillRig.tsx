import { useMemo, useRef, useEffect } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { frame } from './choreography'
import { stage } from '../store/stage'
import { scrollState } from '../lib/scroll'
import { isFinePointer } from '../lib/motion'
import { PINK_ROYAL, PINK_DEEP, MAGENTA_GLOW } from './palette'

/**
 * The persistent pink capsule: two lathe halves with a beveled seam, candy
 * clearcoat, fresnel rim glow, an inner "powder" face visible when open,
 * and a soft glow billboard behind it.
 */

const R = 0.62
const HALF_LEN = 0.72

function makeHalfGeometry() {
  const pts: THREE.Vector2[] = []
  // open face lip -> tight beveled seam -> cylinder wall -> dome
  // (a deep seam recess reads as a "broken" pill at small scales)
  pts.push(new THREE.Vector2(0.5, 0))
  pts.push(new THREE.Vector2(0.605, 0.008))
  pts.push(new THREE.Vector2(R, 0.045))
  const cylSteps = 5
  for (let i = 1; i <= cylSteps; i++) {
    pts.push(new THREE.Vector2(R, 0.07 + (HALF_LEN - 0.07) * (i / cylSteps)))
  }
  const hemiSteps = 22
  for (let i = 1; i <= hemiSteps; i++) {
    const a = (i / hemiSteps) * Math.PI * 0.5
    pts.push(new THREE.Vector2(Math.cos(a) * R, HALF_LEN + Math.sin(a) * R * 0.96))
  }
  const g = new THREE.LatheGeometry(pts, 64)
  g.computeVertexNormals()
  return g
}

const rimVertex = /* glsl */ `
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    vN = normalize(normalMatrix * normal);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vV = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`
// Subsurface fake: edges glow lighter (light scattering through the candy
// shell) with a warm blush mid-band, a crisp magenta rim at grazing angles.
const rimFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform vec3 uCore;
  uniform float uIntensity;
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    float fres = 1.0 - abs(dot(normalize(vN), normalize(vV)));
    float rim = pow(fres, 2.6);          // tight bright edge
    float scatter = pow(fres, 1.1) * 0.5; // soft inner translucency
    vec3 col = mix(uCore, uColor, rim);
    gl_FragColor = vec4(col, (rim + scatter) * uIntensity);
  }
`

const glowVertex = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`
// Hand-rolled radial bloom: a wide soft halo + a tight hot core that reads as
// a candy glow even on the porcelain background. Two-tone so the center burns
// toward blush-white and the falloff carries the magenta.
const glowFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform vec3 uCore;
  uniform float uIntensity;
  varying vec2 vUv;
  void main() {
    float d = length(vUv - 0.5) * 2.0;
    float halo = exp(-d * 2.1);
    float core = exp(-d * 6.0);
    vec3 col = mix(uColor, uCore, core);
    float a = (halo * 0.55 + core * 0.85) * uIntensity;
    gl_FragColor = vec4(col, clamp(a, 0.0, 1.0) * 0.72);
  }
`

export default function PillRig() {
  const group = useRef<THREE.Group>(null!)
  const axis = useRef<THREE.Group>(null!)
  const top = useRef<THREE.Group>(null!)
  const bottom = useRef<THREE.Group>(null!)
  const glowRef = useRef<THREE.Mesh>(null!)
  const spin = useRef(0)
  const tilt = useRef({ x: 0, y: 0 })
  const finePointer = useMemo(() => isFinePointer(), [])

  const halfGeo = useMemo(makeHalfGeometry, [])
  const fillGeo = useMemo(() => {
    const g = new THREE.CircleGeometry(0.44, 40)
    g.rotateX(Math.PI / 2) // face -Y (outward from the open half)
    return g
  }, [])
  const glowGeo = useMemo(() => new THREE.PlaneGeometry(1, 1), [])

  const mats = useMemo(() => {
    const body = new THREE.MeshPhysicalMaterial({
      color: PINK_ROYAL,
      roughness: 0.19,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0.08, // wetter, crisper specular streak
      sheen: 0.7,
      sheenRoughness: 0.4,
      sheenColor: new THREE.Color(MAGENTA_GLOW),
      iridescence: 0.18, // faint candy-shell shimmer
      iridescenceIOR: 1.3,
      envMapIntensity: 1.35, // pick up the studio Lightformers harder
      emissive: new THREE.Color(PINK_DEEP),
      emissiveIntensity: 0.06,
      transparent: true,
    })
    const cap = body.clone()
    // near-royal, one step deeper — two-tone without ever reading black
    cap.color = new THREE.Color('#ef2f85')
    cap.emissiveIntensity = 0.12
    const fill = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#e0407f'),
      roughness: 0.95,
      metalness: 0,
      transparent: true,
      // never write depth: an invisible disk that still writes depth
      // occludes the far half of the capsule at steep view angles
      depthWrite: false,
    })
    const rim = new THREE.ShaderMaterial({
      vertexShader: rimVertex,
      fragmentShader: rimFragment,
      uniforms: {
        uColor: { value: new THREE.Color(MAGENTA_GLOW) },
        uCore: { value: new THREE.Color('#ffd9ec') }, // blush scatter
        uIntensity: { value: 0.5 },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
    const glow = new THREE.ShaderMaterial({
      vertexShader: glowVertex,
      fragmentShader: glowFragment,
      uniforms: {
        uColor: { value: new THREE.Color(MAGENTA_GLOW) },
        uCore: { value: new THREE.Color('#ffe9f4') }, // near-white hot core
        uIntensity: { value: 0.5 },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: false,
    })
    return { body, cap, fill, rim, glow }
  }, [])

  useEffect(() => {
    return () => {
      halfGeo.dispose()
      fillGeo.dispose()
      glowGeo.dispose()
      Object.values(mats).forEach((m) => m.dispose())
    }
  }, [halfGeo, fillGeo, glowGeo, mats])

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05)
    const t = state.clock.elapsedTime
    const g = group.current
    if (!g) return

    // pose from choreography
    g.position.set(
      frame.pos.x,
      frame.pos.y + Math.sin(t * 0.85) * 0.05, // breathing float
      0,
    )
    g.scale.setScalar(frame.scale)

    // idle life + interaction
    spin.current += dt * (frame.isMobile ? 0.5 : 0.34) * (1 + Math.abs(scrollState.norm) * 0.8)
    axis.current.rotation.y = spin.current

    const targetTiltX = finePointer ? stage.pointerY * 0.22 : Math.sin(t * 0.4) * 0.1
    const targetTiltY = finePointer ? stage.pointerX * 0.3 : Math.cos(t * 0.33) * 0.14
    tilt.current.x = THREE.MathUtils.damp(tilt.current.x, targetTiltX, 5, dt)
    tilt.current.y = THREE.MathUtils.damp(tilt.current.y, targetTiltY, 5, dt)
    g.rotation.x = 0.32 + tilt.current.x
    g.rotation.y = tilt.current.y
    g.rotation.z = -0.52

    // split choreography: halves part along the axis, tilt, drift, fade
    const s = frame.split
    const drift = s * s * 1.1
    top.current.position.y = s * 0.62 + drift * 0.9
    bottom.current.position.y = -(s * 0.62 + drift * 0.9)
    top.current.rotation.z = s * 0.42
    // π is the mirror flip that makes this the LOWER half — never lose it
    bottom.current.rotation.z = Math.PI - s * 0.36
    top.current.position.x = s * 0.22
    bottom.current.position.x = -s * 0.18

    const a = frame.halvesAlpha
    mats.body.opacity = a
    mats.cap.opacity = a
    mats.fill.opacity = a * Math.min(1, s * 3) // powder face only reads when open
    mats.fill.visible = s > 0.02
    const shellVisible = a > 0.01 && frame.scale > 0.002
    top.current.visible = shellVisible
    bottom.current.visible = shellVisible
    mats.rim.uniforms.uIntensity.value = (0.42 + frame.glow * 0.5) * a

    // glow billboard
    const glow = glowRef.current
    glow.position.set(frame.pos.x, frame.pos.y, -1.6)
    const pulse = 1 + Math.abs(scrollState.norm) * 0.4 + Math.sin(t * 1.3) * 0.06
    // wider halo so the bloom reads as ambient energy, not a tight disk
    glow.scale.setScalar(Math.max(0.001, 7.2 * frame.scale * pulse))
    mats.glow.uniforms.uIntensity.value = 0.4 + frame.glow * 0.85
    glow.visible = frame.glow > 0.02 && frame.scale > 0.002
  })

  return (
    <>
      <group ref={group}>
        <group ref={axis}>
          <group ref={top}>
            <mesh geometry={halfGeo} material={mats.body} />
            <mesh geometry={halfGeo} material={mats.rim} scale={1.025} />
            <mesh geometry={fillGeo} material={mats.fill} position-y={0.004} />
          </group>
          <group ref={bottom} rotation-z={Math.PI}>
            <mesh geometry={halfGeo} material={mats.cap} />
            <mesh geometry={halfGeo} material={mats.rim} scale={1.025} />
            <mesh geometry={fillGeo} material={mats.fill} position-y={0.004} />
          </group>
        </group>
      </group>
      <mesh ref={glowRef} geometry={glowGeo} material={mats.glow} renderOrder={-1} />
    </>
  )
}
