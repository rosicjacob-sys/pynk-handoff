import { useMemo, useRef, useEffect } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { frame } from './choreography'
import { scrollState } from '../lib/scroll'
import { PINK_ROYAL, MAGENTA_GLOW, PINK_DEEP } from './palette'

/**
 * Proof section: the one pill multiplies into a loose parallax wall scattered
 * around the margins (center band kept clear for the reviews), then every
 * instance converges into the buy anchor.
 */

const COUNT = 56

interface Slot {
  nx: number // normalized [-0.5, 0.5]
  ny: number
  z: number
  scale: number
  rotX: number
  rotY: number
  spin: number
  delay: number
  tone: number
}

function mulberry32(a: number) {
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export default function PillWall() {
  const meshRef = useRef<THREE.InstancedMesh>(null!)
  const dummy = useMemo(() => new THREE.Object3D(), [])
  const pillPos = useMemo(() => new THREE.Vector3(), [])

  const slots = useMemo<Slot[]>(() => {
    const rnd = mulberry32(20260707)
    const out: Slot[] = []
    while (out.length < COUNT) {
      const nx = (rnd() - 0.5) * 1.04
      const ny = (rnd() - 0.5) * 1.0
      // the wall lives in the margins, behind the content plane — the
      // odometer and review rail keep a clear stage
      if (Math.abs(nx) < 0.36 && Math.abs(ny) < 0.44) continue
      out.push({
        nx,
        ny,
        z: -4.2 + rnd() * 2.7, // always behind the hero pill's plane
        scale: 0.1 + rnd() * 0.18,
        rotX: rnd() * Math.PI,
        rotY: rnd() * Math.PI,
        spin: (rnd() - 0.5) * 0.7,
        delay: rnd(),
        tone: rnd(),
      })
    }
    return out
  }, [])

  const geometry = useMemo(() => new THREE.CapsuleGeometry(0.62, 1.34, 5, 18), [])
  const material = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: PINK_ROYAL,
        roughness: 0.3,
        metalness: 0,
        clearcoat: 0.8,
        clearcoatRoughness: 0.25,
        emissive: new THREE.Color(PINK_DEEP),
        emissiveIntensity: 0.05,
        transparent: true,
        opacity: 0,
      }),
    [],
  )

  useEffect(() => {
    const mesh = meshRef.current
    if (mesh) {
      const glow = new THREE.Color(MAGENTA_GLOW)
      const royal = new THREE.Color(PINK_ROYAL)
      const c = new THREE.Color()
      for (let i = 0; i < COUNT; i++) {
        c.copy(royal).lerp(glow, slots[i].tone * 0.45)
        mesh.setColorAt(i, c)
      }
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
    }
    return () => {
      geometry.dispose()
      material.dispose()
    }
  }, [geometry, material, slots])

  useFrame((state, dtRaw) => {
    const mesh = meshRef.current
    if (!mesh) return
    const wallT = frame.wallT
    const conv = frame.convergeT
    const active = wallT > 0.004 && !(conv > 0.995)
    mesh.visible = active
    // ghosted depth layer: blooms out, then recedes while the reviews are read
    const recede = 1 - 0.45 * Math.min(1, Math.max(0, (wallT - 0.75) * 4))
    material.opacity = Math.min(1, wallT * 1.6) * 0.48 * recede
    if (!active) return

    const dt = Math.min(dtRaw, 0.05)
    const t = state.clock.elapsedTime
    const { wu, hu } = frame
    pillPos.set(frame.pos.x, frame.pos.y, 0)

    for (let i = 0; i < COUNT; i++) {
      const s = slots[i]
      // multiply out of the hero pill, staggered
      const ti = Math.min(1, Math.max(0, wallT * 1.45 - s.delay * 0.45))
      const e = 1 - Math.pow(1 - ti, 3)
      // converge into the buy anchor, staggered
      const ci = Math.min(1, Math.max(0, conv * 1.4 - s.delay * 0.4))
      const ec = ci * ci * ci

      // scale world position by camera distance so the SCREEN position
      // matches the slot's normalized coords — the keep-out band holds at depth
      const persp = (8 - s.z) / 8 // camera sits at z=8
      const px = s.nx * wu * persp
      const py =
        s.ny * hu * persp +
        Math.sin(t * 0.5 + s.delay * 9.0) * 0.12 +
        scrollState.norm * s.z * 0.35 // depth parallax vs scroll velocity
      const pz = s.z

      let x = pillPos.x + (px - pillPos.x) * e
      let y = pillPos.y + (py - pillPos.y) * e
      let z = pz * e
      x += (frame.buy.x - x) * ec
      y += (frame.buy.y - y) * ec
      z += (0.4 - z) * ec

      s.rotX += s.spin * dt
      dummy.position.set(x, y, z)
      dummy.rotation.set(s.rotX, s.rotY + t * 0.1 * s.spin, s.delay * Math.PI)
      dummy.scale.setScalar(Math.max(0.0001, s.scale * e * (1 - ec)))
      dummy.updateMatrix()
      mesh.setMatrixAt(i, dummy.matrix)
    }
    mesh.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh
      ref={meshRef}
      args={[geometry, material, COUNT]}
      frustumCulled={false}
      visible={false}
    />
  )
}
