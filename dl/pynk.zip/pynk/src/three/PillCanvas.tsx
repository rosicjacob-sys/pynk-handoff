import { useState } from 'react'
import { Canvas, useFrame, useThree, advance } from '@react-three/fiber'

if (import.meta.env.DEV && typeof window !== 'undefined') {
  // QA hook: lets tooling pump frames when rAF is throttled (background tabs)
  ;(window as unknown as Record<string, unknown>).__advance = advance
}
import { Environment, Lightformer, PerformanceMonitor } from '@react-three/drei'
import { computeFrame } from './choreography'
import { perfState } from './palette'
import { reportGlFailure } from '../lib/glsignal'
import PillRig from './PillRig'
import Granules from './Granules'
import PillWall from './PillWall'

/** Runs before every other useFrame: derives the shared pose for this frame. */
function Driver() {
  const { viewport, size } = useThree()
  const get = useThree((s) => s.get)
  useFrame((_, dt) => {
    if (import.meta.env.DEV) {
      const w = window as unknown as Record<string, number>
      w.__frameCount = (w.__frameCount ?? 0) + 1
      w.__lastDt = dt
    }
    computeFrame(Math.min(dt, 0.05), viewport.width, viewport.height, size.width, size.height)
  }, -10)
  if (import.meta.env.DEV && typeof window !== 'undefined') {
    ;(window as unknown as Record<string, unknown>).__r3fGet = get
  }
  return null
}

export default function PillCanvas() {
  const [dpr, setDpr] = useState<number | [number, number]>([1, 2])

  return (
    <div className="gl-stage" aria-hidden="true">
      <Canvas
        gl={{
          alpha: true,
          antialias: true,
          powerPreference: 'high-performance',
          failIfMajorPerformanceCaveat: true,
        }}
        style={{ pointerEvents: 'none' }}
        dpr={dpr}
        camera={{ fov: 42, position: [0, 0, 8], near: 0.1, far: 50 }}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener(
            'webglcontextlost',
            (e) => {
              e.preventDefault()
              reportGlFailure()
            },
            false,
          )
        }}
      >
        {/* NOTE: no flipflops/onFallback — drei counts every incline event
            toward `flipped`, so a healthy machine would hit the fallback and
            permanently nuke quality. Decline/incline alone is stable. */}
        <PerformanceMonitor
          onDecline={() => {
            // sustained low fps: step quality DOWN relative to the device —
            // a fixed number would raise resolution on devicePixelRatio<=1
            setDpr(Math.max(0.75, Math.min(window.devicePixelRatio || 1, 2) * 0.6))
            perfState.q = 0.5
          }}
          onIncline={() => {
            setDpr([1, 2])
            perfState.q = 1
          }}
        >
          <Driver />
          <ambientLight intensity={0.55} color="#fff0f6" />
          <directionalLight position={[4, 5, 6]} intensity={1.6} color="#ffffff" />
          <pointLight position={[-5, -2, -4]} intensity={36} color="#ff5fa8" />
          <Environment resolution={128} frames={1}>
            {/* studio-soft top light, warm key, pink rim — fully procedural, no network HDRI */}
            <Lightformer intensity={3.5} position={[0, 4, 3]} scale={[9, 3, 1]} color="#ffffff" />
            <Lightformer intensity={1.8} position={[5, 0, 2]} scale={[4, 5, 1]} color="#ffe9f0" />
            <Lightformer
              intensity={2.6}
              position={[-5, -1, -3]}
              rotation-y={Math.PI}
              scale={[6, 6, 1]}
              color="#ff5fa8"
            />
          </Environment>
          <PillRig />
          <Granules />
          <PillWall />
        </PerformanceMonitor>
      </Canvas>
    </div>
  )
}
