import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { track } from '../lib/analytics'
import { VARIANTS, type VariantId } from '../data/product'

export interface CartItem {
  variantId: VariantId
  qty: number
}

interface CartState {
  items: CartItem[]
  open: boolean
  /** bumps whenever something is added — drives the badge pop + fly target */
  lastAddedAt: number
  /** the pack currently highlighted in the buy card + sticky bar */
  selectedVariant: VariantId
  add: (variantId: VariantId, qty?: number) => void
  remove: (variantId: VariantId) => void
  setQty: (variantId: VariantId, qty: number) => void
  setOpen: (open: boolean) => void
  setSelectedVariant: (id: VariantId) => void
}

export const useCart = create<CartState>()(
  persist(
    (set) => ({
      items: [],
      open: false,
      lastAddedAt: 0,
      selectedVariant: 'triple',
      add: (variantId, qty = 1) =>
        set((s) => {
          const existing = s.items.find((it) => it.variantId === variantId)
          const items = existing
            ? s.items.map((it) =>
                it.variantId === variantId
                  ? { ...it, qty: Math.min(it.qty + qty, 99) }
                  : it,
              )
            : [...s.items, { variantId, qty: Math.min(qty, 99) }]
          track('add_to_cart', {
            currency: 'USD',
            value: Number((VARIANTS[variantId].price * qty).toFixed(2)),
            items: [{ item_id: variantId, quantity: qty }],
          })
          return { items, lastAddedAt: Date.now() }
        }),
      remove: (variantId) =>
        set((s) => ({ items: s.items.filter((it) => it.variantId !== variantId) })),
      setQty: (variantId, qty) =>
        set((s) => ({
          items:
            qty <= 0
              ? s.items.filter((it) => it.variantId !== variantId)
              : s.items.map((it) =>
                  it.variantId === variantId ? { ...it, qty: Math.min(qty, 99) } : it,
                ),
        })),
      setOpen: (open) => set({ open }),
      setSelectedVariant: (id) => set({ selectedVariant: id }),
    }),
    {
      name: 'pynk-cart-v1',
      version: 1,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ items: s.items }),
      // never trust rehydrated storage: drop unknown/renamed variants and
      // clamp quantities so VARIANTS[...] lookups can't explode the page
      merge: (persisted, current) => {
        const p = persisted as { items?: unknown } | undefined
        const items = Array.isArray(p?.items)
          ? (p!.items as CartItem[]).filter(
              (it) =>
                it &&
                typeof it === 'object' &&
                Object.prototype.hasOwnProperty.call(VARIANTS, it.variantId) &&
                Number.isFinite(it.qty),
            ).map((it) => ({ variantId: it.variantId, qty: Math.min(Math.max(1, Math.round(it.qty)), 99) }))
          : []
        return { ...current, items }
      },
      migrate: (persisted) => persisted as { items: CartItem[] },
    },
  ),
)

export const cartCount = (items: CartItem[]) =>
  items.reduce((sum, it) => sum + it.qty, 0)

export const cartSubtotal = (items: CartItem[]) =>
  items.reduce((sum, it) => sum + VARIANTS[it.variantId].price * it.qty, 0)
