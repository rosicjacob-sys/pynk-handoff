/**
 * Shared mutable scroll-stage state. DOM-side ScrollTriggers write progress;
 * the R3F scene reads it every frame. Plain module object — no re-renders.
 */
export const stage = {
  heroP: 0,
  scienceP: 0,
  howP: 0,
  proofP: 0,
  buyP: 0,
  outroP: 0,
  /** cursor in [-1, 1], fine pointers only */
  pointerX: 0,
  pointerY: 0,
  /** buy packshot anchor, in document px (screen = doc - scrollY) */
  buyAnchorDocX: 0,
  buyAnchorDocY: 0,
  hasBuyAnchor: false,
}

if (import.meta.env.DEV && typeof window !== 'undefined') {
  ;(window as unknown as Record<string, unknown>).__stage = stage
}

/** Pentagon layout shared between the 3D granule clusters and the DOM labels (apex up). */
export const NODE_ANGLES = [90, 162, 234, 306, 18].map((d) => (d * Math.PI) / 180)

/** Node ring radius as a fraction of the smaller viewport dimension. */
export const NODE_RADIUS_VMIN = 0.24
