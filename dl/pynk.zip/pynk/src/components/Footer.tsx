import { useState, type FormEvent } from 'react'
import Reveal from './ui/Reveal'
import { scrollToEl } from '../lib/scroll'
import { FDA_DISCLAIMER } from '../data/product'

export default function Footer() {
  const [email, setEmail] = useState('')
  const [done, setDone] = useState(false)

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!email.includes('@')) return
    setDone(true)
  }

  const go = (e: React.MouseEvent, href: string) => {
    if (!href.startsWith('#')) return
    e.preventDefault()
    scrollToEl(href)
  }

  return (
    <footer className="footer" data-dark>
      <div className="container">
        <Reveal y={40}>
          <div className="footer__wordmark" aria-hidden="true">
            PYNK<em>.</em>
          </div>
        </Reveal>
        <div className="footer__grid">
          <div className="newsletter">
            <h3 className="footer__h">The pink list</h3>
            <p>
              One useful email a month — restocks, research summaries, zero
              spam. Unsubscribe in one tap.
            </p>
            <form
              className={`newsletter__form ${done ? 'is-done' : ''}`}
              onSubmit={submit}
            >
              <label htmlFor="newsletter-email" className="sr-only" style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clipPath: 'inset(50%)' }}>
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={done}
              />
              <button type="submit" aria-label="Join the list">
                {done ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="m5 12.5 5 5L19 7" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M4 12h15m-6-7 7 7-7 7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </button>
            </form>
            <p className="newsletter__ok" aria-live="polite">
              {done ? 'You’re on the list. Welcome to the pink side.' : ''}
            </p>
          </div>
          <div>
            <h3 className="footer__h">Shop</h3>
            <div className="footer__links">
              <a href="#buy" onClick={(e) => go(e, '#buy')}>
                1 bottle
              </a>
              <a href="#buy" onClick={(e) => go(e, '#buy')}>
                3-pack
              </a>
              <a href="#buy" onClick={(e) => go(e, '#buy')}>
                Subscribe & save
              </a>
              <a href="#proof" onClick={(e) => go(e, '#proof')}>
                Reviews
              </a>
            </div>
          </div>
          <div>
            <h3 className="footer__h">Company</h3>
            <div className="footer__links">
              <a href="#science" onClick={(e) => go(e, '#science')}>
                Ingredients
              </a>
              <a href="#faq" onClick={(e) => go(e, '#faq')}>
                FAQ
              </a>
              <a href="mailto:hello@pynk.example">Contact</a>
              <a href="#faq" onClick={(e) => go(e, '#faq')}>
                Shipping & returns
              </a>
            </div>
          </div>
        </div>
        <div className="footer__legal">
          <p>† {FDA_DISCLAIMER}</p>
          <p>
            © 2026 PYNK Labs, Inc. All rights reserved. PYNK is a dietary
            supplement — not a medical treatment. · Privacy · Terms
          </p>
        </div>
      </div>
    </footer>
  )
}
