import { useEffect, useRef, useState } from 'react'
import { useCart, cartSubtotal, cartCount } from '../store/cart'
import { checkout } from '../lib/checkout'
import { getLenis, scrollToEl } from '../lib/scroll'
import { toast } from './Toast'
import { VARIANTS, FREE_SHIPPING_THRESHOLD, money } from '../data/product'

export default function CartDrawer() {
  const items = useCart((s) => s.items)
  const open = useCart((s) => s.open)
  const setOpen = useCart((s) => s.setOpen)
  const setQty = useCart((s) => s.setQty)
  const remove = useCart((s) => s.remove)
  const [busy, setBusy] = useState(false)
  const closeRef = useRef<HTMLButtonElement>(null)
  const returnFocusRef = useRef<HTMLElement | null>(null)
  const wasOpen = useRef(false)

  const subtotal = cartSubtotal(items)
  const count = cartCount(items)
  const shipProgress = Math.min(1, subtotal / FREE_SHIPPING_THRESHOLD)
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal

  // lock page scroll behind the drawer, make the page inert (real modal:
  // Tab can't reach covered controls), esc to close, restore focus on close
  useEffect(() => {
    const lenis = getLenis()
    const inertTargets = [
      document.getElementById('main'),
      document.querySelector<HTMLElement>('.nav'),
      document.querySelector<HTMLElement>('.sticky-bar'),
    ].filter(Boolean) as HTMLElement[]

    if (open) {
      returnFocusRef.current = document.activeElement as HTMLElement | null
      wasOpen.current = true
      lenis?.stop()
      document.body.style.overflow = 'hidden'
      inertTargets.forEach((el) => el.setAttribute('inert', ''))
      closeRef.current?.focus()
    } else {
      lenis?.start()
      document.body.style.overflow = ''
      inertTargets.forEach((el) => el.removeAttribute('inert'))
      if (wasOpen.current) {
        returnFocusRef.current?.focus?.()
        returnFocusRef.current = null
      }
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
      lenis?.start()
      document.body.style.overflow = ''
      inertTargets.forEach((el) => el.removeAttribute('inert'))
    }
  }, [open, setOpen])

  const onCheckout = async () => {
    if (busy || items.length === 0) return
    setBusy(true)
    try {
      const result = await checkout(items)
      toast(result.message ?? (result.ok ? 'Checkout started.' : 'Checkout failed — try again.'))
    } catch {
      toast('Checkout failed — try again.')
    } finally {
      setBusy(false)
    }
  }

  const goShop = () => {
    setOpen(false)
    scrollToEl('#buy')
  }

  return (
    <div className={open ? 'cart-open' : ''}>
      <div className="cart-backdrop" onClick={() => setOpen(false)} aria-hidden="true" />
      <aside
        className="cart-drawer"
        role="dialog"
        aria-modal="true"
        aria-label="Shopping cart"
        aria-hidden={!open}
      >
        <div className="cart-drawer__head">
          <h3>
            Your cart {count > 0 && <span className="accent">({count})</span>}
          </h3>
          <button
            ref={closeRef}
            type="button"
            className="cart-drawer__close"
            onClick={() => setOpen(false)}
            aria-label="Close cart"
            tabIndex={open ? 0 : -1}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M6 6l12 12M18 6 6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {items.length > 0 && (
          <div className="freeship">
            {remaining > 0 ? (
              <>You’re {money(remaining)} away from free US shipping</>
            ) : (
              <>Free shipping unlocked.</>
            )}
            <div className="freeship__track">
              <div
                className="freeship__fill"
                style={{ transform: `scaleX(${shipProgress})` }}
              />
            </div>
          </div>
        )}

        <div className="cart-drawer__items">
          {items.length === 0 ? (
            <div className="cart-empty">
              <p>Your cart is empty.</p>
              <button type="button" className="btn btn--primary" onClick={goShop} tabIndex={open ? 0 : -1}>
                Take the pink one
              </button>
            </div>
          ) : (
            items.map((it) => {
              const v = VARIANTS[it.variantId]
              return (
                <div className="cart-line" key={it.variantId}>
                  <div className="cart-line__thumb" aria-hidden="true" />
                  <div className="cart-line__body">
                    <div className="cart-line__name">PYNK Daily — {v.name}</div>
                    <div className="cart-line__meta">{v.meta}</div>
                    <div className="qty" aria-label={`Quantity for ${v.name}`}>
                      <button type="button" onClick={() => setQty(it.variantId, it.qty - 1)} aria-label="Decrease" tabIndex={open ? 0 : -1}>
                        −
                      </button>
                      <span>{it.qty}</span>
                      <button type="button" onClick={() => setQty(it.variantId, it.qty + 1)} aria-label="Increase" tabIndex={open ? 0 : -1}>
                        +
                      </button>
                    </div>
                  </div>
                  <div style={{ display: 'grid', gap: '0.4rem', justifyItems: 'end' }}>
                    <div className="cart-line__price">{money(v.price * it.qty)}</div>
                    <button type="button" className="cart-line__remove" onClick={() => remove(it.variantId)} tabIndex={open ? 0 : -1}>
                      Remove
                    </button>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {items.length > 0 && (
          <div className="cart-drawer__foot">
            <div className="cart-drawer__subtotal">
              <span>Subtotal</span>
              <span>{money(subtotal)}</span>
            </div>
            <button
              type="button"
              className="btn btn--primary btn--big"
              onClick={onCheckout}
              disabled={busy}
              tabIndex={open ? 0 : -1}
            >
              {busy ? 'Starting checkout…' : 'Checkout'}
            </button>
            <p className="cart-drawer__note">
              Secure checkout · 30-day money-back guarantee · taxes calculated at checkout
            </p>
          </div>
        )}
      </aside>
    </div>
  )
}
