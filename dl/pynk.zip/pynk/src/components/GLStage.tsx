import { Component, Suspense, lazy, useEffect, useState, type ReactNode } from 'react'
import { glStatus, reportGlFailure } from '../lib/glsignal'
import { bootDone } from '../lib/boot'

const PillCanvas = lazy(() => import('../three/PillCanvas'))

class GLErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch(err: unknown) {
    console.warn('[PYNK] WebGL scene failed, falling back to static hero.', err)
    reportGlFailure()
  }
  render() {
    return this.state.failed ? null : this.props.children
  }
}

/**
 * Mounts the single persistent WebGL context — lazily, after boot + idle so
 * the 3D bundle never blocks first paint. Any failure flips the page to the
 * static pink fallback via the glsignal event.
 */
export default function GLStage({ enabled }: { enabled: boolean }) {
  const [ready, setReady] = useState(false)
  const [failed, setFailed] = useState(glStatus.failed)

  useEffect(() => {
    const onFail = () => setFailed(true)
    window.addEventListener('pynk:glfail', onFail)
    let idleId = 0
    let done = false
    const hasIdle = typeof window.requestIdleCallback === 'function'
    bootDone.then(() => {
      if (done) return
      const kick = () => setReady(true)
      idleId = hasIdle
        ? window.requestIdleCallback(kick, { timeout: 400 })
        : window.setTimeout(kick, 120)
    })
    return () => {
      done = true
      window.removeEventListener('pynk:glfail', onFail)
      if (hasIdle) window.cancelIdleCallback(idleId)
      else window.clearTimeout(idleId)
    }
  }, [])

  if (!enabled || failed || !ready) return null
  return (
    <GLErrorBoundary>
      <Suspense fallback={null}>
        <PillCanvas />
      </Suspense>
    </GLErrorBoundary>
  )
}
