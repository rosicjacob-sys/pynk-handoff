import { useEffect, useRef, useState } from 'react'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import Magnetic from './ui/Magnetic'
import { useKineticType } from './ui/useKineticType'
import { glStatus } from '../lib/glsignal'
import { scrollToEl } from '../lib/scroll'
import { RATING } from '../data/product'

/**
 * Hero. The 3D pill lives on the fixed canvas, center-right; the right grid
 * column + `hero__pill-space` reserve its room so there is zero layout shift.
 * `flat` (no WebGL / reduced motion / gl failure) swaps in the CSS pill.
 */
export default function Hero({ flat }: { flat: boolean }) {
  const kineticRef = useRef<HTMLDivElement>(null)
  const [failed, setFailed] = useState(glStatus.failed)
  useKineticType(kineticRef)

  useEffect(() => {
    const onFail = () => setFailed(true)
    window.addEventListener('pynk:glfail', onFail)
    return () => window.removeEventListener('pynk:glfail', onFail)
  }, [])

  const showFallback = flat || failed

  return (
    <section className="hero" id="top">
      {showFallback && (
        <div className="hero-fallback" aria-hidden="true">
          <div className="hero-fallback__bloom" />
          <div className="hero-fallback__pill" />
        </div>
      )}
      <div className="hero__inner">
        <div className="hero__copy">
          <Reveal delay={0.05}>
            <span className="eyebrow">Daily focus + clean energy</span>
          </Reveal>
          <div ref={kineticRef}>
            <SplitReveal
              as="h1"
              className="display-xl hero__title"
              delay={0.1}
              lines={[
                <>Take the</>,
                <>
                  <em className="accent">pink</em> one.
                </>,
              ]}
            />
          </div>
          <Reveal delay={0.45}>
            <p className="lede hero__sub">
              Five studied ingredients, full doses, zero caffeine. One glossy
              capsule that supports calm focus and clean energy
              <sup className="fda-ref" aria-hidden="true">
                †
              </sup>{' '}
              — every single morning.
            </p>
          </Reveal>
          <Reveal delay={0.55}>
            <div className="hero__cta-row">
              <Magnetic>
                <button
                  type="button"
                  className="btn btn--primary"
                  data-cursor="shop"
                  onClick={() => scrollToEl('#buy')}
                >
                  Shop PYNK
                </button>
              </Magnetic>
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() => scrollToEl('#science')}
              >
                See the science
              </button>
            </div>
          </Reveal>
          <Reveal delay={0.68}>
            <ul className="trust-row">
              <li>
                <span className="stars" aria-hidden="true">
                  ★★★★★
                </span>
                {RATING.score} ({RATING.count.toLocaleString('en-US')} reviews)
              </li>
              <li>Third-party tested</li>
              <li>Made in the USA</li>
            </ul>
          </Reveal>
        </div>
        <div className="hero__pill-space" aria-hidden="true" />
      </div>
      <div className="hero__scroll-cue" aria-hidden="true">
        Scroll
      </div>
    </section>
  )
}
