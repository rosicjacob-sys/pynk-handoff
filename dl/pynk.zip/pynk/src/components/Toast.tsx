import { useEffect, useRef, useState } from 'react'

export function toast(message: string) {
  window.dispatchEvent(new CustomEvent('pynk:toast', { detail: message }))
}

export default function Toast() {
  const [msg, setMsg] = useState('')
  const [on, setOn] = useState(false)
  const timer = useRef(0)

  useEffect(() => {
    const onToast = (e: Event) => {
      setMsg((e as CustomEvent<string>).detail)
      setOn(true)
      window.clearTimeout(timer.current)
      timer.current = window.setTimeout(() => setOn(false), 2600)
    }
    window.addEventListener('pynk:toast', onToast)
    return () => {
      window.removeEventListener('pynk:toast', onToast)
      window.clearTimeout(timer.current)
    }
  }, [])

  return (
    <div className={`toast ${on ? 'is-on' : ''}`} role="status" aria-live="polite">
      {msg}
    </div>
  )
}
