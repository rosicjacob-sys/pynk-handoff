import { MARQUEE_ITEMS } from '../data/product'

/** Infinite badge marquee — pure CSS loop, pauses on hover, static under reduced motion. */
export default function TrustMarquee() {
  return (
    <div className="marquee" aria-label="Certifications and guarantees">
      <div className="marquee__track">
        {[0, 1].map((dup) => (
          <span key={dup} aria-hidden={dup === 1} style={{ display: 'contents' }}>
            {MARQUEE_ITEMS.map((item) => (
              <span className="marquee__item" key={`${dup}-${item}`}>
                {item}
              </span>
            ))}
          </span>
        ))}
      </div>
    </div>
  )
}
