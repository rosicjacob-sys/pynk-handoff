import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { ScrollTrigger, getScrollY } from '../lib/scroll'
import { stage } from '../store/stage'
import { prefersReducedMotion } from '../lib/motion'
import { flyToCart } from '../lib/flyToCart'
import { track } from '../lib/analytics'
import { useCart } from '../store/cart'
import { toast } from './Toast'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import Magnetic from './ui/Magnetic'
import {
  VARIANTS,
  VARIANT_ORDER,
  INGREDIENTS,
  RATING,
  FDA_DISCLAIMER,
  SUPPLEMENT_WARNING,
  money,
} from '../data/product'

/**
 * Honest dispatch messaging: the 3pm cutoff is evaluated in the warehouse's
 * timezone (ET), not the visitor's, and weekends never claim same-day.
 */
function useShipCountdown() {
  const compute = (): string => {
    let et: Date
    try {
      et = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }))
    } catch {
      return 'Ships within one business day.'
    }
    const day = et.getDay()
    if (day === 0 || day === 6) return 'Ships Monday morning.'
    const cutoff = new Date(et)
    cutoff.setHours(15, 0, 0, 0)
    if (et >= cutoff) {
      return day === 5 ? 'Ships Monday morning.' : 'Ships tomorrow morning.'
    }
    const mins = Math.floor((cutoff.getTime() - et.getTime()) / 60000)
    return `Order within ${Math.floor(mins / 60)}h ${mins % 60}m — ships today.`
  }
  const [msg, setMsg] = useState(compute)
  useEffect(() => {
    const id = window.setInterval(() => setMsg(compute()), 30000)
    return () => window.clearInterval(id)
  }, [])
  return msg
}

export default function BuyBlock() {
  const secRef = useRef<HTMLElement>(null)
  const packRef = useRef<HTMLImageElement>(null)
  const addBtnRef = useRef<HTMLButtonElement>(null)
  const selected = useCart((s) => s.selectedVariant)
  const setSelected = useCart((s) => s.setSelectedVariant)
  const add = useCart((s) => s.add)
  const setOpen = useCart((s) => s.setOpen)
  const [qty, setQty] = useState(1)
  const shipMsg = useShipCountdown()
  const variant = VARIANTS[selected]

  // Buy-converge scroll progress + view_item analytics
  useLayoutEffect(() => {
    const sec = secRef.current
    if (!sec) return

    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          track('view_item', { item_id: 'pynk-daily', item_name: 'PYNK Daily' })
          io.disconnect()
        }
      },
      { threshold: 0.35 },
    )
    io.observe(sec)

    let st: ScrollTrigger | undefined
    if (!prefersReducedMotion()) {
      st = ScrollTrigger.create({
        trigger: sec,
        start: 'top 85%',
        end: 'center 45%',
        scrub: 0.5,
        invalidateOnRefresh: true,
        onUpdate: (self) => {
          stage.buyP = self.progress
        },
      })
    }
    return () => {
      io.disconnect()
      st?.kill()
    }
  }, [])

  // Publish the packshot's document-space anchor for the 3D convergence —
  // measured on layout/refresh/resize only, never inside a frame loop.
  useEffect(() => {
    const img = packRef.current
    if (!img) return
    const measure = () => {
      const r = img.getBoundingClientRect()
      stage.buyAnchorDocX = r.left + r.width * 0.5
      stage.buyAnchorDocY = r.top + getScrollY() + r.height * 0.42
      stage.hasBuyAnchor = true
    }
    const raf = requestAnimationFrame(measure)
    window.addEventListener('resize', measure)
    // 'refresh' fires AFTER pin spacing is re-applied — 'refreshInit' would
    // measure the document with the Science pin reverted (~2.6 viewports off)
    ScrollTrigger.addEventListener('refresh', measure)
    img.addEventListener('load', measure)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', measure)
      ScrollTrigger.removeEventListener('refresh', measure)
      img.removeEventListener('load', measure)
      stage.hasBuyAnchor = false
    }
  }, [])

  const onAdd = () => {
    add(selected, qty)
    const target = document.getElementById('cart-target')
    if (addBtnRef.current && target) flyToCart(addBtnRef.current, target)
    toast('Added — the pink one is yours.')
    window.setTimeout(() => setOpen(true), prefersReducedMotion() ? 0 : 780)
  }

  return (
    <section className="buy section" id="buy" ref={secRef}>
      <div className="container">
        <div className="buy__grid">
          <Reveal className="buy__visual" y={40}>
            <img
              ref={packRef}
              className="buy__packshot"
              src="img/pynk-bottle.webp"
              alt="PYNK Daily bottle with pink capsules"
              width={900}
              height={900}
              loading="lazy"
            />
          </Reveal>

          <div>
            <div className="buy-card">
              <div className="buy-card__rating">
                <span className="stars" aria-hidden="true">
                  ★★★★★
                </span>
                {RATING.score} · {RATING.count.toLocaleString('en-US')} verified reviews
              </div>
              <SplitReveal as="h2" stagger={0.02}>
                PYNK Daily
              </SplitReveal>
              <p className="buy-card__tag">
                30 capsules · calm focus + clean energy, one pink pill a day.
              </p>

              <div className="variants" role="radiogroup" aria-label="Choose your pack">
                {VARIANT_ORDER.map((id) => {
                  const v = VARIANTS[id]
                  return (
                    <label
                      key={id}
                      className={`variant ${selected === id ? 'is-active' : ''}`}
                    >
                      <input
                        type="radio"
                        name="variant"
                        value={id}
                        checked={selected === id}
                        onChange={() => setSelected(id)}
                      />
                      <span className="variant__radio" aria-hidden="true" />
                      <span className="variant__body">
                        <span className="variant__name">
                          {v.name}
                          {v.badge && (
                            <span className={`badge ${id === 'subscription' ? 'badge--soft' : ''}`}>
                              {v.badge}
                            </span>
                          )}
                        </span>
                        <span className="variant__meta">{v.meta}</span>
                      </span>
                      <span className="variant__price">
                        {money(v.price)}
                        {v.cadence ?? ''}
                        {v.compareAt && <s>{money(v.compareAt)}</s>}
                      </span>
                    </label>
                  )
                })}
              </div>

              <div className="buy-card__row">
                <div className="qty" aria-label="Quantity">
                  <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity">
                    −
                  </button>
                  <span aria-live="polite">{qty}</span>
                  <button type="button" onClick={() => setQty((q) => Math.min(9, q + 1))} aria-label="Increase quantity">
                    +
                  </button>
                </div>
                <Magnetic className="buy-card__cta" strength={0.22}>
                  <button
                    ref={addBtnRef}
                    type="button"
                    className="btn btn--primary btn--big"
                    data-cursor="add"
                    onClick={onAdd}
                  >
                    Add to cart · {money(variant.price * qty)}
                  </button>
                </Magnetic>
              </div>

              <p className="buy-card__urgency">{shipMsg}</p>

              <ul className="buy-card__trust">
                <li>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6l-7-3Z" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  Third-party tested
                </li>
                <li>30-day money-back guarantee</li>
                <li>Secure checkout</li>
                <li>Free US shipping over $50</li>
              </ul>
              <div className="pay-badges" aria-label="Accepted payments">
                <span>VISA</span>
                <span>MASTERCARD</span>
                <span>AMEX</span>
                <span>APPLE PAY</span>
              </div>

              <details className="facts">
                <summary>Supplement Facts</summary>
                <table>
                  <thead>
                    <tr>
                      <th scope="col">Amount per capsule</th>
                      <th scope="col" aria-label="dose" />
                    </tr>
                  </thead>
                  <tbody>
                    {INGREDIENTS.map((ing) => (
                      <tr key={ing.name}>
                        <td>{ing.name}</td>
                        <td>
                          {ing.dose} {ing.unit}
                        </td>
                      </tr>
                    ))}
                    <tr>
                      <td>Other: vegan cellulose capsule, rice flour, beetroot color</td>
                      <td />
                    </tr>
                  </tbody>
                </table>
                <p className="facts__fine">
                  <strong>Suggested use:</strong> one capsule daily with food.{' '}
                  {SUPPLEMENT_WARNING}
                </p>
                <p className="facts__fine">{FDA_DISCLAIMER}</p>
              </details>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
