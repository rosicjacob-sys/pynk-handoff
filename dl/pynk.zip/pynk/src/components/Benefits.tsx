import type { ReactNode } from 'react'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import { BENEFITS, FDA_DISCLAIMER } from '../data/product'

const ICONS: Record<string, ReactNode> = {
  focus: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="3" fill="currentColor" />
    </svg>
  ),
  energy: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M13 3 5 14h5l-1 7 8-11h-5l1-7Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  ),
  stress: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M3 9c3-3 6 3 9 0s6 3 9 0M3 15c3-3 6 3 9 0s6 3 9 0" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  ),
  memory: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M12 4a5 5 0 0 0-5 5c-2 .5-3 2-3 4a4 4 0 0 0 4 4h8a4 4 0 0 0 4-4c0-2-1-3.5-3-4a5 5 0 0 0-5-5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      <path d="M12 9v4M9.5 11.5h5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  ),
  tested: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6l-7-3Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      <path d="m8.8 12 2.2 2.2 4.2-4.4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  simple: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="3" y="9" width="18" height="7" rx="3.5" transform="rotate(-20 12 12.5)" stroke="currentColor" strokeWidth="1.8" />
      <path d="m9.2 13.9 6-2.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  ),
}

export default function Benefits() {
  return (
    <section className="benefits section">
      <div className="container">
        <Reveal>
          <span className="eyebrow">Why PYNK</span>
        </Reveal>
        <SplitReveal
          as="h2"
          className="display-lg"
          stagger={0.028}
          lines={[<>Built for the</>, <span className="accent">long game.</span>]}
        />
        <div className="benefits__grid">
          {BENEFITS.map((b, i) => (
            <Reveal key={b.title} delay={(i % 3) * 0.09 + Math.floor(i / 3) * 0.05}>
              <article className="benefit-card">
                <div className="benefit-card__icon">{ICONS[b.icon]}</div>
                <h3>{b.title}</h3>
                <p>
                  {b.body}
                  <sup className="fda-ref" aria-hidden="true">
                    †
                  </sup>
                </p>
              </article>
            </Reveal>
          ))}
        </div>
        <p className="claims-note">† {FDA_DISCLAIMER}</p>
      </div>
    </section>
  )
}
