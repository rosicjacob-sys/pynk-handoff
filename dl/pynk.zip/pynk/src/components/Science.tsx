import { useLayoutEffect, useRef, useState } from 'react'
import { gsap, ScrollTrigger } from '../lib/scroll'
import { stage, NODE_ANGLES, NODE_RADIUS_VMIN } from '../store/stage'
import { prefersReducedMotion } from '../lib/motion'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import CountUp from './ui/CountUp'
import { INGREDIENTS, FDA_DISCLAIMER } from '../data/product'

/**
 * THE signature section (dark). Desktop: pinned 260% scrub — the capsule
 * splits, granules swirl, then snap into the five labeled ingredient nodes.
 * Mobile: unpinned, shorter scrub + a stacked dosage list (no long pins on
 * phones). Reduced motion: everything static and visible.
 */
export default function Science() {
  const secRef = useRef<HTMLElement>(null)
  const stageRef = useRef<HTMLDivElement>(null)
  const headRef = useRef<HTMLDivElement>(null)
  const footRef = useRef<HTMLDivElement>(null)
  const [litCount, setLitCount] = useState(() => (prefersReducedMotion() ? INGREDIENTS.length : 0))

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return
    const sec = secRef.current
    const stageEl = stageRef.current
    if (!sec || !stageEl) return

    let lit = 0
    const applyProgress = (p: number) => {
      stage.scienceP = p
      // the headline hands the stage to the ingredient ring
      const head = headRef.current
      if (head) {
        const fade = Math.min(1, Math.max(0, (p - 0.38) / 0.14))
        head.style.opacity = String(1 - fade)
        head.style.transform = `translateY(${(-26 * fade).toFixed(1)}px)`
      }
      // the FDA line yields to the bottom labels once the ring locks in
      const foot = footRef.current
      if (foot) {
        foot.style.opacity = String(1 - Math.min(1, Math.max(0, (p - 0.48) / 0.1)))
      }
      // labels light up one by one as the clusters lock in
      let n = 0
      for (let i = 0; i < INGREDIENTS.length; i++) {
        if (p > 0.52 + i * 0.055) n = i + 1
      }
      if (n !== lit) {
        lit = n
        setLitCount(n)
      }
    }

    const mm = gsap.matchMedia()
    mm.add('(min-width: 800px)', () => {
      const st = ScrollTrigger.create({
        trigger: sec,
        start: 'top top',
        end: '+=260%',
        pin: stageEl,
        pinSpacing: true,
        anticipatePin: 1,
        scrub: 0.6,
        invalidateOnRefresh: true,
        onUpdate: (self) => applyProgress(self.progress),
      })
      return () => st.kill()
    })
    mm.add('(max-width: 799px)', () => {
      const st = ScrollTrigger.create({
        trigger: sec,
        start: 'top 65%',
        end: 'bottom 60%',
        scrub: 0.5,
        invalidateOnRefresh: true,
        onUpdate: (self) => applyProgress(self.progress),
      })
      return () => st.kill()
    })
    return () => mm.revert()
  }, [])

  // Shared pentagon geometry: labels sit just outside the granule clusters.
  // 58% matches the pill's science pose (y = -0.08 * viewport height).
  const ringPct = NODE_RADIUS_VMIN * 100
  const labelPos = (i: number) => {
    const a = NODE_ANGLES[i]
    const r = ringPct * 1.5
    return {
      left: `calc(50% + ${(Math.cos(a) * r).toFixed(2)}vmin)`,
      top: `calc(58% - ${(Math.sin(a) * r).toFixed(2)}vmin)`,
    }
  }

  return (
    <section className="science" id="science" ref={secRef} data-dark>
      <div className="science__stage" ref={stageRef}>
        <div className="science__head" ref={headRef}>
          <Reveal>
            <span className="eyebrow">The science</span>
          </Reveal>
          <SplitReveal as="h2" className="display-lg">
            Crack it open.
          </SplitReveal>
          <Reveal delay={0.2}>
            <p className="lede">
              Five actives, full doses, no proprietary-blend fog. This is
              everything inside the pink one — swirling in front of you.
            </p>
          </Reveal>
        </div>

        <div className="node-field" aria-hidden="true">
          {INGREDIENTS.map((ing, i) => (
            <div
              key={ing.name}
              className={`node-label ${i < litCount ? 'is-on' : ''}`}
              style={labelPos(i)}
            >
              <div className="node-label__name">{ing.name}</div>
              <div className="node-label__dose">
                <CountUp to={ing.dose} active={i < litCount} duration={1.1} suffix={` ${ing.unit}`} />
              </div>
              <div className="node-label__note">{ing.note}</div>
            </div>
          ))}
        </div>

        {/* mobile: the same facts as a stacked list, count-ups fire on view */}
        <div className="science__list">
          {INGREDIENTS.map((ing) => (
            <div className="science__list-item" key={ing.name}>
              <div>
                <div className="node-label__name">{ing.name}</div>
                <div className="node-label__dose">
                  <CountUp to={ing.dose} duration={1.1} suffix={` ${ing.unit}`} />
                </div>
              </div>
              <div className="node-label__note">{ing.note}</div>
            </div>
          ))}
        </div>

        <div className="science__foot" ref={footRef}>
          {FDA_DISCLAIMER}
        </div>
      </div>
    </section>
  )
}
