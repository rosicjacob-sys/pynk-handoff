import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { prefersReducedMotion, isFinePointer } from '../lib/motion'

/**
 * Context-aware cursor — desktop fine pointers only, gone entirely on touch
 * and under reduced motion. A dot leads, a ring trails; the ring grows and
 * labels itself over elements that declare `data-cursor`.
 */
export default function Cursor() {
  const dotRef = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)
  const labelRef = useRef<HTMLSpanElement>(null)
  const enabled = isFinePointer() && !prefersReducedMotion()

  useEffect(() => {
    if (!enabled) return
    const dot = dotRef.current!
    const ring = ringRef.current!
    const label = labelRef.current!
    document.documentElement.classList.add('has-cursor')

    let mx = innerWidth / 2
    let my = innerHeight / 2
    let dx = mx
    let dy = my
    let rx = mx
    let ry = my
    let seen = false

    const onMove = (e: MouseEvent) => {
      mx = e.clientX
      my = e.clientY
      if (!seen) {
        seen = true
        dx = rx = mx
        dy = ry = my
        gsap.set([dot, ring], { opacity: 1 })
      }
    }
    const onOver = (e: MouseEvent) => {
      const t = e.target as HTMLElement
      const tagged = t.closest<HTMLElement>('[data-cursor]')
      const interactive = t.closest('a, button, summary, label, [role="button"]')
      if (tagged) {
        label.textContent = tagged.dataset.cursor ?? ''
        ring.classList.add('is-label')
      } else {
        ring.classList.remove('is-label')
        gsap.to(ring, {
          scale: interactive ? 1.5 : 1,
          duration: 0.25,
          ease: 'power3.out',
        })
      }
    }
    const onLeave = () => gsap.set([dot, ring], { opacity: 0 })
    const onEnter = () => gsap.set([dot, ring], { opacity: 1 })

    const tick = () => {
      dx += (mx - dx) * 0.4
      dy += (my - dy) * 0.4
      rx += (mx - rx) * 0.17
      ry += (my - ry) * 0.17
      dot.style.transform = `translate3d(${dx}px, ${dy}px, 0)`
      ring.style.transform = `translate3d(${rx}px, ${ry}px, 0)`
    }

    gsap.set([dot, ring], { opacity: 0 })
    gsap.ticker.add(tick)
    window.addEventListener('mousemove', onMove, { passive: true })
    document.addEventListener('mouseover', onOver, { passive: true })
    document.documentElement.addEventListener('mouseleave', onLeave)
    document.documentElement.addEventListener('mouseenter', onEnter)

    return () => {
      gsap.ticker.remove(tick)
      window.removeEventListener('mousemove', onMove)
      document.removeEventListener('mouseover', onOver)
      document.documentElement.removeEventListener('mouseleave', onLeave)
      document.documentElement.removeEventListener('mouseenter', onEnter)
      document.documentElement.classList.remove('has-cursor')
      gsap.killTweensOf([dot, ring])
    }
  }, [enabled])

  if (!enabled) return null
  return (
    <>
      <div className="cursor-dot" ref={dotRef} aria-hidden="true" />
      <div className="cursor-ring" ref={ringRef} aria-hidden="true">
        <span ref={labelRef} />
      </div>
    </>
  )
}
