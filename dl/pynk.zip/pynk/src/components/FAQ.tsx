import { useLayoutEffect, useRef, useState } from 'react'
import { ScrollTrigger } from '../lib/scroll'
import { stage } from '../store/stage'
import { prefersReducedMotion } from '../lib/motion'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import { FAQS, FDA_DISCLAIMER, SUPPLEMENT_WARNING } from '../data/product'

export default function FAQ() {
  const secRef = useRef<HTMLElement>(null)
  const [open, setOpen] = useState<number>(0)

  // outro: the pill bows out as the FAQ arrives
  useLayoutEffect(() => {
    if (prefersReducedMotion()) return
    const sec = secRef.current
    if (!sec) return
    const st = ScrollTrigger.create({
      trigger: sec,
      start: 'top 85%',
      end: 'top 35%',
      scrub: 0.5,
      invalidateOnRefresh: true,
      onUpdate: (self) => {
        stage.outroP = self.progress
      },
    })
    return () => {
      st.kill()
    }
  }, [])

  return (
    <section className="section" id="faq" ref={secRef}>
      <div className="container faq">
        <Reveal>
          <span className="eyebrow">Good questions</span>
        </Reveal>
        <SplitReveal as="h2" className="display-lg" stagger={0.028}>
          Asked. Answered.
        </SplitReveal>
        <div style={{ marginTop: '2.5rem' }}>
          {FAQS.map((f, i) => (
            <div className={`faq-item ${open === i ? 'is-open' : ''}`} key={f.q}>
              <button
                type="button"
                id={`faq-q-${i}`}
                className="faq-item__q"
                aria-expanded={open === i}
                aria-controls={`faq-a-${i}`}
                onClick={() => setOpen((cur) => (cur === i ? -1 : i))}
              >
                {f.q}
                <span className="faq-x" aria-hidden="true" />
              </button>
              <div
                className="faq-item__a"
                id={`faq-a-${i}`}
                role="region"
                aria-labelledby={`faq-q-${i}`}
              >
                <div className="faq-item__a-inner">
                  <p>{f.a}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="compliance-note">
          <p>
            <strong>†</strong> {FDA_DISCLAIMER}
          </p>
          <p style={{ marginTop: '0.6rem' }}>{SUPPLEMENT_WARNING}</p>
        </div>
      </div>
    </section>
  )
}
