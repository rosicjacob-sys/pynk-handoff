import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { useCart, cartCount } from '../store/cart'
import { scrollToEl } from '../lib/scroll'
import { prefersReducedMotion } from '../lib/motion'

const LINKS = [
  { label: 'The science', href: '#science' },
  { label: 'How it works', href: '#how' },
  { label: 'Reviews', href: '#proof' },
  { label: 'FAQ', href: '#faq' },
]

export default function Nav() {
  const [solid, setSolid] = useState(false)
  const items = useCart((s) => s.items)
  const lastAddedAt = useCart((s) => s.lastAddedAt)
  const setOpen = useCart((s) => s.setOpen)
  const badgeRef = useRef<HTMLSpanElement>(null)
  const count = cartCount(items)

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // badge pop when something lands in the cart
  useEffect(() => {
    if (!lastAddedAt || !badgeRef.current || prefersReducedMotion()) return
    const tween = gsap.fromTo(
      badgeRef.current,
      { scale: 1 },
      { scale: 1.45, duration: 0.14, yoyo: true, repeat: 1, ease: 'power2.out', delay: 0.72 },
    )
    return () => {
      tween.kill()
    }
  }, [lastAddedAt])

  const go = (e: React.MouseEvent, href: string) => {
    e.preventDefault()
    scrollToEl(href)
  }

  return (
    <header className={`nav ${solid ? 'is-solid' : ''}`}>
      <div className="nav__inner">
        <a
          href="#top"
          className="nav__brand"
          onClick={(e) => go(e, '#top')}
          aria-label="PYNK — back to top"
        >
          PYNK<em>.</em>
        </a>
        <nav className="nav__links" aria-label="Sections">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={(e) => go(e, l.href)}>
              {l.label}
            </a>
          ))}
        </nav>
        <button
          type="button"
          className="cart-btn"
          id="cart-target"
          onClick={() => setOpen(true)}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path
              d="M5 8h14l-1.2 11a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 8Z"
              stroke="currentColor"
              strokeWidth="1.8"
            />
            <path d="M8.5 8V6.5a3.5 3.5 0 0 1 7 0V8" stroke="currentColor" strokeWidth="1.8" />
          </svg>
          Cart
          <span className="cart-btn__badge" ref={badgeRef}>
            {count}
          </span>
        </button>
      </div>
    </header>
  )
}
