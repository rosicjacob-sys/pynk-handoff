import { useEffect, useRef, useState } from 'react'
import { useCart } from '../store/cart'
import { flyToCart } from '../lib/flyToCart'
import { prefersReducedMotion } from '../lib/motion'
import { toast } from './Toast'
import { VARIANTS, money } from '../data/product'

/**
 * Slim always-one-tap-away buy bar. Appears once the hero scrolls out,
 * retreats while the buy card or the cart drawer is on screen.
 */
export default function StickyBuyBar() {
  const [heroGone, setHeroGone] = useState(false)
  const [buyVisible, setBuyVisible] = useState(false)
  const [footerVisible, setFooterVisible] = useState(false)
  const btnRef = useRef<HTMLButtonElement>(null)
  const selected = useCart((s) => s.selectedVariant)
  const add = useCart((s) => s.add)
  const open = useCart((s) => s.open)
  const setOpen = useCart((s) => s.setOpen)
  const variant = VARIANTS[selected]

  useEffect(() => {
    const hero = document.getElementById('top')
    const buy = document.getElementById('buy')
    const footer = document.querySelector('.footer')
    if (!hero || !buy || !footer) return
    const heroIO = new IntersectionObserver(
      ([e]) => setHeroGone(!e.isIntersecting),
      { threshold: 0.08 },
    )
    const buyIO = new IntersectionObserver(
      ([e]) => setBuyVisible(e.isIntersecting),
      { threshold: 0.25 },
    )
    // retire while the footer is on screen — never cover the legal line
    const footIO = new IntersectionObserver(([e]) => setFooterVisible(e.isIntersecting))
    heroIO.observe(hero)
    buyIO.observe(buy)
    footIO.observe(footer)
    return () => {
      heroIO.disconnect()
      buyIO.disconnect()
      footIO.disconnect()
    }
  }, [])

  const onAdd = () => {
    add(selected, 1)
    const target = document.getElementById('cart-target')
    if (btnRef.current && target) flyToCart(btnRef.current, target)
    toast('Added — the pink one is yours.')
    window.setTimeout(() => setOpen(true), prefersReducedMotion() ? 0 : 780)
  }

  const visible = heroGone && !buyVisible && !footerVisible && !open

  return (
    <div className={`sticky-bar ${visible ? 'is-visible' : ''}`} aria-hidden={!visible}>
      <div className="sticky-bar__info">
        <div className="sticky-bar__name">PYNK Daily — {variant.name}</div>
        <div className="sticky-bar__price">
          {money(variant.price)}
          {variant.cadence ?? ''} · free US shipping over $50
        </div>
      </div>
      <button
        ref={btnRef}
        type="button"
        className="btn btn--primary"
        data-cursor="add"
        onClick={onAdd}
        tabIndex={visible ? 0 : -1}
      >
        Add to cart
      </button>
    </div>
  )
}
