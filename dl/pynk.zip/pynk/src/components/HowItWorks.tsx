import { useLayoutEffect, useRef, useState } from 'react'
import { ScrollTrigger } from '../lib/scroll'
import { stage } from '../store/stage'
import { prefersReducedMotion } from '../lib/motion'
import SplitReveal from './ui/SplitReveal'
import Reveal from './ui/Reveal'
import { STEPS } from '../data/product'

/**
 * Three steps with a pink progress rail that draws down the section while the
 * granules stream + re-form the pill on the canvas beside it.
 */
export default function HowItWorks() {
  const secRef = useRef<HTMLElement>(null)
  const fillRef = useRef<HTMLDivElement>(null)
  const [pastCount, setPastCount] = useState(() =>
    prefersReducedMotion() ? STEPS.length : 0,
  )

  useLayoutEffect(() => {
    if (prefersReducedMotion()) {
      if (fillRef.current) fillRef.current.style.transform = 'scaleY(1)'
      return
    }
    const sec = secRef.current
    if (!sec) return

    let past = 0
    const st = ScrollTrigger.create({
      trigger: sec,
      start: 'top 62%',
      end: 'bottom 62%',
      scrub: 0.5,
      invalidateOnRefresh: true,
      onUpdate: (self) => {
        const p = self.progress
        stage.howP = p
        if (fillRef.current) fillRef.current.style.transform = `scaleY(${p})`
        let n = 0
        for (let i = 0; i < STEPS.length; i++) {
          if (p > (i + 0.35) / STEPS.length) n = i + 1
        }
        if (n !== past) {
          past = n
          setPastCount(n)
        }
      },
    })
    return () => {
      st.kill()
    }
  }, [])

  return (
    <section className="how section" id="how" ref={secRef}>
      <div className="container">
        <Reveal>
          <span className="eyebrow">How it works</span>
        </Reveal>
        <SplitReveal
          as="h2"
          className="display-lg"
          stagger={0.028}
          lines={[<>One capsule.</>, <span className="accent">Zero ceremony.</span>]}
        />
        <div className="how__grid" style={{ marginTop: '3.5rem' }}>
          <div className="how__steps">
            <div className="how__rail" aria-hidden="true">
              <div className="how__rail-fill" ref={fillRef} />
            </div>
            {STEPS.map((step, i) => (
              <Reveal key={step.title} delay={i * 0.08}>
                <div className={`how-step ${i < pastCount ? 'is-past' : ''}`}>
                  <span className="how-step__num" aria-hidden="true">
                    {i + 1}
                  </span>
                  <h3>{step.title}</h3>
                  <p>{step.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
          {/* the re-forming pill on the fixed canvas occupies this column */}
          <div aria-hidden="true" />
        </div>
      </div>
    </section>
  )
}
