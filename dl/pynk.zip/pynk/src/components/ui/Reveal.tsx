import { useLayoutEffect, useRef, type ReactNode } from 'react'
import gsap from 'gsap'
import { prefersReducedMotion, failsafe } from '../../lib/motion'
import { bootDone } from '../../lib/boot'

interface Props {
  children: ReactNode
  className?: string
  delay?: number
  y?: number
  /** also draw scaleX for hairlines */
  draw?: boolean
}

/**
 * Block entrance: y + fade (or scaleX draw), played once on visibility.
 * The wall-clock failsafe only exists for the case where IntersectionObserver
 * never delivers at all — the observer's FIRST callback (even a non-intersecting
 * one) proves it works and stands the failsafe down, so below-fold entrances
 * are never force-completed early.
 */
export default function Reveal({ children, className, delay = 0, y = 26, draw = false }: Props) {
  const ref = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const el = ref.current
    if (!el || prefersReducedMotion()) return

    let tween: gsap.core.Tween | null = null
    let io: IntersectionObserver | null = null
    let cancel: (() => void) | null = null
    let disposed = false

    const show = () => {
      if (tween) tween.progress(1)
      else gsap.set(el, { clearProps: 'all' })
    }

    bootDone.then(() => {
      if (disposed) return
      tween = draw
        ? gsap.from(el, {
            scaleX: 0,
            duration: 1.1,
            ease: 'power4.out',
            delay,
            paused: true,
          })
        : gsap.from(el, {
            y,
            autoAlpha: 0,
            duration: 0.95,
            ease: 'power3.out',
            delay,
            paused: true,
          })
      cancel = failsafe(show, 3500)
      io = new IntersectionObserver(
        (entries) => {
          // observer works — the never-stay-hidden rescue is no longer needed
          cancel?.()
          cancel = null
          if (entries.some((e) => e.isIntersecting)) {
            tween?.play()
            io?.disconnect()
            io = null
          }
        },
        { threshold: 0.18 },
      )
      io.observe(el)
    })

    return () => {
      disposed = true
      cancel?.()
      io?.disconnect()
      tween?.kill()
    }
  }, [delay, y, draw])

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  )
}
