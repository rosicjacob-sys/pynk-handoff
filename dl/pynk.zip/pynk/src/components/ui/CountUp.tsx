import { useEffect, useRef, useState } from 'react'
import { prefersReducedMotion } from '../../lib/motion'

interface Props {
  to: number
  /** starts counting when this flips true; if omitted, counts when visible */
  active?: boolean
  duration?: number
  format?: (n: number) => string
  className?: string
  suffix?: string
}

const defaultFormat = (n: number) => Math.round(n).toLocaleString('en-US')

/** rAF-eased count-up with a 1-frame tick flash exactly when it lands. */
export default function CountUp({
  to,
  active,
  duration = 1.6,
  format = defaultFormat,
  className,
  suffix = '',
}: Props) {
  const ref = useRef<HTMLSpanElement>(null)
  const [visible, setVisible] = useState(false)
  const started = useRef(false)

  // Visibility trigger (only used when `active` prop isn't supplied)
  useEffect(() => {
    if (active !== undefined) return
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    // failsafe: never leave the number at 0 if IO fails
    const t = window.setTimeout(() => setVisible(true), 3500)
    return () => {
      io.disconnect()
      window.clearTimeout(t)
    }
  }, [active])

  const go = active !== undefined ? active : visible

  useEffect(() => {
    const el = ref.current
    if (!el || !go || started.current) return
    started.current = true

    if (prefersReducedMotion()) {
      el.textContent = format(to) + suffix
      return
    }

    let raf = 0
    const t0 = performance.now()
    const ms = duration * 1000
    const tickAt = to
    const step = (now: number) => {
      const p = Math.min(1, (now - t0) / ms)
      const eased = 1 - Math.pow(1 - p, 4)
      el.textContent = format(tickAt * eased) + suffix
      if (p < 1) {
        raf = requestAnimationFrame(step)
      } else {
        el.classList.add('tick')
        window.setTimeout(() => el.classList.remove('tick'), 340)
      }
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [go, to, duration, format, suffix])

  return (
    <span ref={ref} className={`tickable ${className ?? ''}`}>
      {prefersReducedMotion() ? format(to) + suffix : format(0) + suffix}
    </span>
  )
}
