import { useLayoutEffect, type RefObject } from 'react'
import gsap from 'gsap'
import { scrollState } from '../../lib/scroll'
import { prefersReducedMotion, isDesktop } from '../../lib/motion'

/**
 * Scroll-velocity kinetic type (Law 3): one style write per frame on the
 * container — variable weight + capped skew. No layout reads in the loop.
 */
export function useKineticType(
  ref: RefObject<HTMLElement | null>,
  { baseWeight = 590, range = 55, maxSkew = 2 } = {},
) {
  useLayoutEffect(() => {
    const el = ref.current
    if (!el || prefersReducedMotion() || !isDesktop()) return

    let weight = baseWeight
    let skew = 0
    const tick = () => {
      const v = scrollState.norm // [-1, 1]
      weight += (baseWeight + v * range - weight) * 0.12
      skew += (v * -maxSkew - skew) * 0.12
      el.style.fontVariationSettings = `'wght' ${weight.toFixed(1)}`
      el.style.transform = `skewX(${skew.toFixed(3)}deg)`
    }
    gsap.ticker.add(tick)
    return () => {
      gsap.ticker.remove(tick)
      el.style.fontVariationSettings = ''
      el.style.transform = ''
    }
  }, [ref, baseWeight, range, maxSkew])
}
