import {
  useLayoutEffect,
  useRef,
  type ElementType,
  type ReactNode,
} from 'react'
import gsap from 'gsap'
import SplitType from 'split-type'
import { prefersReducedMotion, failsafe } from '../../lib/motion'
import { bootDone } from '../../lib/boot'

interface Props {
  as?: ElementType
  className?: string
  children?: ReactNode
  /**
   * Author-controlled line breaks. SplitType's automatic line grouping
   * fragments around nested elements (accent spans), so display headlines
   * pass explicit lines; each becomes its own masked block and only chars
   * are split inside it.
   */
  lines?: ReactNode[]
  /** per-char stagger */
  stagger?: number
  delay?: number
  id?: string
}

/** fonts.ready, but never waited on for more than `ms` (slow-connection cap) */
const fontsReadyCapped = (ms: number) =>
  Promise.race([
    document.fonts.ready.catch(() => {}),
    new Promise((r) => setTimeout(r, ms)),
  ])

/**
 * Masked char reveal (Law 3): y 110% -> 0, power4.out, fired once on
 * visibility after boot. The wall-clock failsafe stands down as soon as the
 * IntersectionObserver proves it works (first callback), so entrances still
 * play for below-fold sections. Screen readers get the intact heading text
 * via aria-label; the split chars are hidden from the accessibility tree.
 * Reduced motion: no split, no hide, nothing to fail.
 */
export default function SplitReveal({
  as: Tag = 'h2',
  className,
  children,
  lines,
  stagger = 0.032,
  delay = 0,
  id,
}: Props) {
  const ref = useRef<HTMLElement>(null)

  useLayoutEffect(() => {
    const el = ref.current
    if (!el || prefersReducedMotion()) return

    let splits: SplitType[] = []
    let tween: gsap.core.Tween | null = null
    let io: IntersectionObserver | null = null
    let cancelFailsafe: (() => void) | null = null
    let disposed = false

    const forceVisible = () => {
      if (tween) tween.progress(1)
      else gsap.set(el, { autoAlpha: 1 })
    }

    const run = async () => {
      // Split only after fonts + boot so line boxes measure correctly —
      // but never stall the entrance behind a slow font download.
      await Promise.all([fontsReadyCapped(2500), bootDone])
      if (disposed) return

      // keep the heading readable for assistive tech before fragmenting it
      const plainText = (el.textContent ?? '').replace(/\s+/g, ' ').trim()
      if (plainText) el.setAttribute('aria-label', plainText)

      let chars: HTMLElement[] = []
      if (lines) {
        const lineEls = Array.from(el.querySelectorAll<HTMLElement>('.sr-line'))
        splits = lineEls.map(
          (lineEl) => new SplitType(lineEl, { types: 'chars', charClass: 'sr-char' }),
        )
        chars = splits.flatMap((s) => s.chars ?? [])
        lineEls.forEach((lineEl) => lineEl.setAttribute('aria-hidden', 'true'))
      } else {
        const split = new SplitType(el as HTMLElement, {
          types: 'lines,chars',
          lineClass: 'sr-line',
          charClass: 'sr-char',
        })
        splits = [split]
        chars = split.chars ?? []
        el.querySelectorAll('.sr-line').forEach((lineEl) =>
          lineEl.setAttribute('aria-hidden', 'true'),
        )
      }
      if (chars.length === 0) return

      tween = gsap.from(chars, {
        yPercent: 112,
        duration: 0.9,
        ease: 'power4.out',
        stagger,
        delay,
        paused: true,
      })

      cancelFailsafe = failsafe(forceVisible, 3500)

      io = new IntersectionObserver(
        (entries) => {
          // observer works — the never-stay-hidden rescue is no longer needed
          cancelFailsafe?.()
          cancelFailsafe = null
          if (entries.some((e) => e.isIntersecting)) {
            tween?.play()
            io?.disconnect()
            io = null
          }
        },
        { threshold: 0.25 },
      )
      io.observe(el)
    }
    run()

    return () => {
      disposed = true
      cancelFailsafe?.()
      io?.disconnect()
      tween?.kill()
      splits.forEach((s) => s.revert())
      el.removeAttribute('aria-label')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stagger, delay])

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const AnyTag = Tag as any
  return (
    <AnyTag ref={ref} className={className} id={id}>
      {lines
        ? lines.map((line, i) => (
            <span className="sr-line" key={i}>
              {line}
            </span>
          ))
        : children}
    </AnyTag>
  )
}
