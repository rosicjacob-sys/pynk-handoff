import { useLayoutEffect, useRef } from 'react'
import { gsap, ScrollTrigger } from '../lib/scroll'
import { stage } from '../store/stage'
import { prefersReducedMotion } from '../lib/motion'
import Reveal from './ui/Reveal'
import CountUp from './ui/CountUp'
import { REVIEWS, PILLS_TAKEN } from '../data/product'

/**
 * Proof: the big odometer + a scroll-driven testimonial rail while the pill
 * multiplies into the parallax wall on the canvas behind. Reduced motion:
 * the rail becomes a normal horizontal scroller.
 */
export default function Proof() {
  const secRef = useRef<HTMLElement>(null)
  const railRef = useRef<HTMLDivElement>(null)
  const wrapRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const sec = secRef.current
    const rail = railRef.current
    const wrap = wrapRef.current
    if (!sec || !rail || !wrap) return
    // reduced motion: the CSS native horizontal scroller is the whole story
    if (prefersReducedMotion()) return

    const mm = gsap.matchMedia()

    // desktop fine pointer: scrub the rail through its FULL measured travel
    mm.add('(min-width: 800px) and (pointer: fine)', () => {
      wrap.classList.add('is-scrub')
      let maxShift = 0
      const measure = () => {
        maxShift = Math.max(0, rail.scrollWidth - wrap.clientWidth + 48)
      }
      measure()
      const st = ScrollTrigger.create({
        trigger: sec,
        start: 'top 78%',
        end: 'bottom 25%',
        scrub: 0.7,
        invalidateOnRefresh: true,
        onRefresh: measure,
        onUpdate: (self) => {
          stage.proofP = self.progress
          rail.style.transform = `translate3d(${(-self.progress * maxShift).toFixed(1)}px, 0, 0)`
        },
      })
      return () => {
        st.kill()
        wrap.classList.remove('is-scrub')
        rail.style.transform = ''
      }
    })

    // touch / small screens: native swipe for the rail, scroll still drives
    // the 3D pill wall behind it
    mm.add('(max-width: 799px), (pointer: coarse)', () => {
      const st = ScrollTrigger.create({
        trigger: sec,
        start: 'top 78%',
        end: 'bottom 25%',
        scrub: 0.7,
        invalidateOnRefresh: true,
        onUpdate: (self) => {
          stage.proofP = self.progress
        },
      })
      return () => st.kill()
    })

    return () => mm.revert()
  }, [])

  return (
    <section className="proof section" id="proof" ref={secRef}>
      <div className="container">
        <div className="proof__stat">
          <Reveal>
            <span className="eyebrow">Proof</span>
          </Reveal>
          <div className="odometer">
            <CountUp to={PILLS_TAKEN} duration={2.2} />
            <span className="accent">+</span>
          </div>
          <div className="proof__stat-label">
            pink ones taken this year, by people who kept the habit
          </div>
        </div>
      </div>
      <div className="proof__rail-wrap" ref={wrapRef}>
        <div className="proof__rail" ref={railRef}>
          {REVIEWS.map((r) => (
            <figure className="review-card" key={r.name}>
              <div className="stars" aria-label={`${r.stars} out of 5 stars`}>
                {'★'.repeat(r.stars)}
                {'☆'.repeat(5 - r.stars)}
              </div>
              <blockquote>“{r.quote}”</blockquote>
              <figcaption>
                {r.name} · <span className="verified">{r.detail}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
