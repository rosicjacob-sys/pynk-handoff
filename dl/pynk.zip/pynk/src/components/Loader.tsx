import { useLayoutEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { finishBoot } from '../lib/boot'
import { prefersReducedMotion } from '../lib/motion'

/**
 * Boot loader — hard-capped by wall clock (setTimeout), so a background tab's
 * throttled rAF can never hang it. Reduced motion skips it entirely.
 */
export default function Loader() {
  const [gone, setGone] = useState(() => prefersReducedMotion())
  const rootRef = useRef<HTMLDivElement>(null)
  const fillRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    if (gone) {
      finishBoot()
      return
    }
    const ctx = gsap.context(() => {
      gsap.to(fillRef.current, { scaleX: 1, duration: 0.7, ease: 'power2.inOut' })
    })
    const t = window.setTimeout(() => {
      finishBoot()
      gsap.to(rootRef.current, {
        autoAlpha: 0,
        duration: 0.55,
        ease: 'power4.inOut',
        onComplete: () => setGone(true),
      })
    }, 850)
    // rAF is throttled in background tabs, so the fade tween may never
    // complete — this wall-clock fallback removes the overlay regardless.
    const hardCap = window.setTimeout(() => setGone(true), 2200)
    return () => {
      window.clearTimeout(t)
      window.clearTimeout(hardCap)
      ctx.revert()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (gone) return null
  return (
    <div className="loader" ref={rootRef} aria-hidden="true">
      <div>
        <div className="loader__mark">
          PYNK<em>.</em>
        </div>
        <div className="loader__bar">
          <div className="loader__fill" ref={fillRef} />
        </div>
      </div>
    </div>
  )
}
