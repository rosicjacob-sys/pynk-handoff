/** All brand copy + commerce data in one place. */

export const BRAND = 'PYNK'
export const FREE_SHIPPING_THRESHOLD = 50
export const RATING = { score: 4.8, count: 2314 }
export const PILLS_TAKEN = 128412

export type VariantId = 'single' | 'triple' | 'subscription'

export interface Variant {
  id: VariantId
  name: string
  meta: string
  price: number
  compareAt?: number
  badge?: string
  cadence?: string
}

export const VARIANTS: Record<VariantId, Variant> = {
  subscription: {
    id: 'subscription',
    name: 'Subscribe & save',
    meta: '30 capsules monthly · cancel anytime',
    price: 31.2,
    compareAt: 39,
    badge: 'Save 20%',
    cadence: '/mo',
  },
  single: {
    id: 'single',
    name: '1 bottle',
    meta: '30 capsules · one month',
    price: 39,
  },
  triple: {
    id: 'triple',
    name: '3-pack',
    meta: '90 capsules · three months',
    price: 99,
    compareAt: 117,
    badge: 'Best value',
  },
}

export const VARIANT_ORDER: VariantId[] = ['subscription', 'triple', 'single']

export interface Ingredient {
  name: string
  dose: number
  unit: string
  note: string
}

export const INGREDIENTS: Ingredient[] = [
  { name: 'L-Theanine', dose: 200, unit: 'mg', note: 'smooth, calm alertness' },
  { name: "Lion's Mane", dose: 500, unit: 'mg', note: 'supports memory + clarity' },
  { name: 'Rhodiola Rosea', dose: 200, unit: 'mg', note: 'supports stress resilience' },
  { name: 'Bacopa Monnieri', dose: 300, unit: 'mg', note: 'supports learning + recall' },
  { name: 'Vitamin B12', dose: 500, unit: 'mcg', note: 'supports cellular energy' },
]

export const MARQUEE_ITEMS = [
  'Third-party tested',
  'cGMP facility',
  'Made in the USA',
  'Caffeine-free',
  'Vegan capsule',
  'No artificial dyes*',
  '30-day guarantee',
]

export const STEPS = [
  {
    title: 'Take one with breakfast',
    body: 'One capsule, water, done. No timing math, no afternoon crash window to plan around.',
  },
  {
    title: 'Let it build',
    body: 'L-Theanine settles in within the hour. The adaptogens — Lion’s Mane, Rhodiola, Bacopa — are designed to compound over weeks of daily use.',
  },
  {
    title: 'Repeat tomorrow',
    body: 'Consistency is the active ingredient. The pink one is simply the easiest habit you’ll keep.',
  },
]

export const BENEFITS = [
  {
    icon: 'focus',
    title: 'Calm focus',
    body: 'L-Theanine supports alert attention without the wired edge.',
  },
  {
    icon: 'energy',
    title: 'Clean energy',
    body: 'B12 supports natural energy metabolism — zero caffeine, zero crash.',
  },
  {
    icon: 'stress',
    title: 'Stress resilience',
    body: 'Rhodiola is a classic adaptogen for steadiness under pressure.',
  },
  {
    icon: 'memory',
    title: 'Memory support',
    body: 'Lion’s Mane and Bacopa support recall and mental clarity.',
  },
  {
    icon: 'tested',
    title: 'Third-party tested',
    body: 'Every batch verified for identity, purity and label accuracy.',
  },
  {
    icon: 'simple',
    title: 'One pill. That’s it.',
    body: 'No powders, no stacks, no eight-step protocol. One pink capsule a day.',
  },
]

export const REVIEWS = [
  {
    stars: 5,
    quote:
      'Week three and my 2pm slump just… stopped showing up. I keep the bottle on my desk like a trophy.',
    name: 'Maya R.',
    detail: 'Verified buyer · 3 months',
  },
  {
    stars: 5,
    quote:
      'I replaced my second coffee with the pink one. Calmer mornings, same output. My meetings thank me.',
    name: 'Daniel K.',
    detail: 'Verified buyer · 6 weeks',
  },
  {
    stars: 4,
    quote:
      'Took about two weeks to notice, exactly like the label says. Now it’s the first thing I pack when I travel.',
    name: 'Priya S.',
    detail: 'Verified buyer · 4 months',
  },
  {
    stars: 5,
    quote:
      'The rare supplement that doesn’t make promises it can’t keep. Steady focus, no jitters, done.',
    name: 'Tom W.',
    detail: 'Verified buyer · 2 months',
  },
  {
    stars: 5,
    quote:
      'Bought it for the color, stayed for the routine. My whole flat share is on the 3-pack now.',
    name: 'Léa M.',
    detail: 'Verified buyer · 5 months',
  },
]

export const FAQS = [
  {
    q: 'What exactly is in PYNK?',
    a: 'Five actives per capsule: L-Theanine (200 mg), Lion’s Mane extract (500 mg), Bacopa Monnieri (300 mg), Rhodiola Rosea (200 mg) and Vitamin B12 (500 mcg), in a vegan cellulose capsule. Full amounts are on the Supplement Facts panel — no proprietary blends, no hidden doses.',
  },
  {
    q: 'When will I feel something?',
    a: 'Honestly: L-Theanine is same-day for most people, while the adaptogens build gradually — most reviewers report a difference after two to three weeks of daily use. This is a ritual, not a rocket.',
  },
  {
    q: 'Is there caffeine or anything stimulant-like?',
    a: 'No caffeine and no stimulants. PYNK is designed to support calm, steady focus. You can keep your coffee — or finally break up with it.',
  },
  {
    q: 'Is it safe? Can I take it with my medication?',
    a: 'PYNK is a dietary supplement made in a cGMP facility and third-party tested every batch. If you are pregnant, nursing, under 18, or taking medication, consult your physician before use.',
  },
  {
    q: 'How does the subscription work?',
    a: 'A fresh bottle ships every 30 days at 20% off. Pause, skip or cancel anytime from your account — two clicks, no phone calls, no guilt trip.',
  },
  {
    q: 'What if it’s not for me?',
    a: 'Every first order carries a 30-day money-back guarantee. Email us, keep the bottle, get refunded. We’d rather lose the sale than the trust.',
  },
]

export const FDA_DISCLAIMER =
  'These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease.'

export const SUPPLEMENT_WARNING =
  'Consult your physician before use if you are pregnant, nursing, taking medication, or have a medical condition. Keep out of reach of children. Do not exceed the suggested use. *Colored with beetroot and carmine-free plant pigments.'

export const money = (n: number) =>
  n.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
