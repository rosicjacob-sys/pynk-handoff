import { useLayoutEffect, useMemo } from 'react'
import { initSmoothScroll, destroySmoothScroll, ScrollTrigger } from './lib/scroll'
import { prefersReducedMotion, isFinePointer } from './lib/motion'
import { gpuTier } from './lib/webgl'
import { stage } from './store/stage'
import Loader from './components/Loader'
import Nav from './components/Nav'
import GLStage from './components/GLStage'
import Hero from './components/Hero'
import TrustMarquee from './components/TrustMarquee'
import Science from './components/Science'
import HowItWorks from './components/HowItWorks'
import Benefits from './components/Benefits'
import Proof from './components/Proof'
import BuyBlock from './components/BuyBlock'
import FAQ from './components/FAQ'
import Footer from './components/Footer'
import StickyBuyBar from './components/StickyBuyBar'
import CartDrawer from './components/CartDrawer'
import Cursor from './components/Cursor'
import Toast from './components/Toast'

export default function App() {
  const show3D = useMemo(() => gpuTier() > 0 && !prefersReducedMotion(), [])

  useLayoutEffect(() => {
    initSmoothScroll()

    // fine-pointer tracking for the pill's magnetic tilt
    let onMove: ((e: MouseEvent) => void) | null = null
    if (isFinePointer() && !prefersReducedMotion()) {
      onMove = (e: MouseEvent) => {
        stage.pointerX = (e.clientX / window.innerWidth) * 2 - 1
        stage.pointerY = -((e.clientY / window.innerHeight) * 2 - 1)
      }
      window.addEventListener('mousemove', onMove, { passive: true })
    }

    // re-measure triggers once real font metrics are in
    document.fonts.ready.then(() => ScrollTrigger.refresh()).catch(() => {})

    // nav adapts while a dark (plum) section passes under it
    let darkCount = 0
    const darkTriggers = prefersReducedMotion()
      ? []
      : Array.from(document.querySelectorAll('[data-dark]')).map((el) =>
          ScrollTrigger.create({
            trigger: el as HTMLElement,
            start: 'top 64px',
            end: 'bottom 64px',
            onToggle: (self) => {
              darkCount += self.isActive ? 1 : -1
              document.documentElement.classList.toggle('nav-on-dark', darkCount > 0)
            },
          }),
        )

    return () => {
      if (onMove) window.removeEventListener('mousemove', onMove)
      darkTriggers.forEach((t) => t.kill())
      document.documentElement.classList.remove('nav-on-dark')
      destroySmoothScroll()
    }
  }, [])

  return (
    <>
      <a className="skip-link" href="#buy">
        Skip to shop
      </a>
      <Loader />
      <Nav />
      <GLStage enabled={show3D} />
      <main id="main">
        <Hero flat={!show3D} />
        <TrustMarquee />
        <Science />
        <HowItWorks />
        <Benefits />
        <Proof />
        <BuyBlock />
        <FAQ />
        <Footer />
      </main>
      <StickyBuyBar />
      <CartDrawer />
      <Cursor />
      <Toast />
    </>
  )
}
