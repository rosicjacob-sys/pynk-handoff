/* Extended QA: cart flow diagnostics, fps, mobile, reduced-motion, WebGL-off. */
import puppeteer from 'puppeteer-core'
import { mkdirSync } from 'node:fs'

const OUT = new URL('./shots/', import.meta.url).pathname
mkdirSync(OUT, { recursive: true })
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
const URL_ = 'http://localhost:5173'
const wait = (ms) => new Promise((r) => setTimeout(r, ms))

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: 'new',
  args: ['--hide-scrollbars', '--force-device-scale-factor=1', '--use-angle=metal'],
})

const errors = []
function wire(page, tag) {
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(`[${tag}] ${m.text()}`)
  })
  page.on('pageerror', (e) => errors.push(`[${tag}] pageerror ${e.message}`))
  page.on('requestfailed', (r) => errors.push(`[${tag}] reqfail ${r.url()}`))
}

/* ---------- desktop: cart flow + fps ---------- */
{
  const page = await browser.newPage()
  wire(page, 'desktop')
  await page.setViewport({ width: 1600, height: 900 })
  await page.goto(URL_, { waitUntil: 'networkidle0' })
  await page.waitForFunction(() => !document.querySelector('.loader'), { timeout: 8000 })
  await page.waitForFunction(() => window.__frame?.intro >= 1, { timeout: 8000 })

  // fps during the pinned science scrub (smooth lenis tween through it)
  const fps = await page.evaluate(async () => {
    const sci = window.__ST.getAll().find((t) => t.trigger?.id === 'science')
    window.__lenis.scrollTo(sci.start, { immediate: true })
    await new Promise((r) => setTimeout(r, 400))
    let frames = 0
    let done = false
    const t0 = performance.now()
    const count = () => {
      frames++
      if (!done) requestAnimationFrame(count)
    }
    requestAnimationFrame(count)
    window.__lenis.scrollTo(sci.end + 200, { duration: 3.5 })
    await new Promise((r) => setTimeout(r, 3600))
    done = true
    const secs = (performance.now() - t0) / 1000
    return Math.round(frames / secs)
  })
  console.log('[fps-science-scrub]', fps)

  // buy flow — real click
  await page.evaluate(() => {
    const y = document.getElementById('buy').getBoundingClientRect().top + window.__lenis.scroll - 80
    window.__lenis.scrollTo(y, { immediate: true })
  })
  await wait(2200)
  const diag = await page.evaluate(() => {
    const btn = document.querySelector('.buy-card .btn--primary')
    const r = btn.getBoundingClientRect()
    const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2)
    return { rect: { x: r.x, y: r.y, w: r.width, h: r.height }, hit: el?.className || el?.tagName, hitIsBtn: el === btn || btn.contains(el) }
  })
  console.log('[click-diag]', JSON.stringify(diag))
  await page.click('.buy-card .btn--primary')
  await wait(500)
  await page.screenshot({ path: OUT + 'c1-fly.png' })
  await wait(1400)
  const cart1 = await page.evaluate(() => ({
    ls: localStorage.getItem('pynk-cart-v1'),
    open: !!document.querySelector('.cart-open'),
    badge: document.querySelector('.cart-btn__badge')?.textContent,
  }))
  console.log('[cart-after-click]', JSON.stringify(cart1))
  await page.screenshot({ path: OUT + 'c2-drawer.png' })

  // drawer interactions: qty up, checkout
  if (cart1.open) {
    await page.click('.cart-line .qty button:last-of-type')
    await wait(300)
    await page.click('.cart-drawer__foot .btn--primary')
    await wait(1200)
    await page.screenshot({ path: OUT + 'c3-checkout.png' })
    const sub = await page.evaluate(() => document.querySelector('.cart-drawer__subtotal')?.textContent)
    console.log('[subtotal]', sub)
  }

  // persistence across reload
  await page.reload({ waitUntil: 'networkidle0' })
  await wait(1500)
  const persisted = await page.evaluate(() => ({
    ls: localStorage.getItem('pynk-cart-v1'),
    badge: document.querySelector('.cart-btn__badge')?.textContent,
  }))
  console.log('[cart-persisted]', JSON.stringify(persisted))
  await page.close()
}

/* ---------- mobile 375px ---------- */
{
  const page = await browser.newPage()
  wire(page, 'mobile')
  await page.setViewport({ width: 375, height: 720, hasTouch: true, isMobile: true })
  await page.goto(URL_, { waitUntil: 'networkidle0' })
  await wait(2500)
  const mob = await page.evaluate(() => ({
    hscroll: document.documentElement.scrollWidth > window.innerWidth,
    canvas: !!document.querySelector('.gl-stage canvas'),
    scrollW: document.documentElement.scrollWidth,
  }))
  console.log('[mobile]', JSON.stringify(mob))
  await page.screenshot({ path: OUT + 'm1-hero.png' })
  await page.evaluate(() => {
    const sci = document.getElementById('science')
    const y = sci.getBoundingClientRect().top + (window.__lenis?.scroll ?? scrollY)
    ;(window.__lenis ?? window).scrollTo(y + innerHeight * 0.8, window.__lenis ? { immediate: true } : undefined)
  })
  await wait(2200)
  await page.screenshot({ path: OUT + 'm2-science.png' })
  await page.evaluate(() => {
    const y = document.getElementById('buy').getBoundingClientRect().top + (window.__lenis?.scroll ?? scrollY)
    ;(window.__lenis ?? window).scrollTo(y - 60, window.__lenis ? { immediate: true } : undefined)
  })
  await wait(2200)
  await page.screenshot({ path: OUT + 'm3-buy.png' })
  // sticky bar presence mid-page
  await page.evaluate(() => {
    const y = document.getElementById('how').getBoundingClientRect().top + (window.__lenis?.scroll ?? scrollY)
    ;(window.__lenis ?? window).scrollTo(y, window.__lenis ? { immediate: true } : undefined)
  })
  await wait(1500)
  const bar = await page.evaluate(() => document.querySelector('.sticky-bar')?.classList.contains('is-visible'))
  console.log('[mobile-stickybar]', bar)
  await page.screenshot({ path: OUT + 'm4-sticky.png' })
  await page.close()
}

/* ---------- reduced motion ---------- */
{
  const page = await browser.newPage()
  wire(page, 'rm')
  await page.setViewport({ width: 1600, height: 900 })
  await page.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }])
  await page.goto(URL_, { waitUntil: 'networkidle0' })
  await wait(2000)
  const rm = await page.evaluate(() => ({
    canvas: !!document.querySelector('.gl-stage canvas'),
    fallbackPill: !!document.querySelector('.hero-fallback__pill'),
    lenis: !!window.__lenis,
    heroTitleVisible: getComputedStyle(document.querySelector('.hero__title')).opacity !== '0',
  }))
  console.log('[reduced-motion]', JSON.stringify(rm))
  await page.screenshot({ path: OUT + 'r1-hero.png' })
  await page.evaluate(() => document.getElementById('science').scrollIntoView())
  await wait(800)
  await page.screenshot({ path: OUT + 'r2-science.png' })
  // buy still works
  await page.evaluate(() => document.getElementById('buy').scrollIntoView())
  await wait(800)
  await page.click('.buy-card .btn--primary')
  await wait(600)
  const rmCart = await page.evaluate(() => ({
    open: !!document.querySelector('.cart-open'),
    ls: !!localStorage.getItem('pynk-cart-v1'),
  }))
  console.log('[rm-cart]', JSON.stringify(rmCart))
  await page.close()
}

/* ---------- WebGL disabled ---------- */
{
  const page = await browser.newPage()
  wire(page, 'nogl')
  await page.setViewport({ width: 1600, height: 900 })
  await page.evaluateOnNewDocument(() => {
    const orig = HTMLCanvasElement.prototype.getContext
    HTMLCanvasElement.prototype.getContext = function (type, ...rest) {
      if (String(type).includes('webgl')) return null
      return orig.call(this, type, ...rest)
    }
  })
  await page.goto(URL_, { waitUntil: 'networkidle0' })
  await wait(2500)
  const nogl = await page.evaluate(() => ({
    canvas: !!document.querySelector('.gl-stage canvas'),
    fallbackPill: !!document.querySelector('.hero-fallback__pill'),
  }))
  console.log('[nogl]', JSON.stringify(nogl))
  await page.screenshot({ path: OUT + 'g1-fallback.png' })
  await page.close()
}

console.log('[console-errors]', errors.length ? errors : 'none')
await browser.close()
console.log('done')
