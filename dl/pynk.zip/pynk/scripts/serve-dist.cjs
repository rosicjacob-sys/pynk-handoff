#!/usr/bin/env node
/**
 * Tiny zero-dependency static server for the PYNK production build.
 * Fronted by `tailscale serve` on a dedicated port so the team can view it.
 *
 * Cache policy matches the deploy contract: HTML is no-cache (a redeploy is
 * seen immediately), hashed assets + fonts are immutable.
 */
const http = require('http')
const fs = require('fs')
const path = require('path')

const ROOT = path.join(__dirname, '..', 'dist')
const PORT = Number(process.env.PYNK_PORT || 8899)
const HOST = '127.0.0.1'

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.woff2': 'font/woff2',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
  '.map': 'application/json',
}

function send(res, status, headers, body) {
  res.writeHead(status, headers)
  if (body) res.end(body)
  else res.end()
}

const server = http.createServer((req, res) => {
  try {
    const urlPath = decodeURIComponent((req.url || '/').split('?')[0])
    // resolve within ROOT, block path traversal
    let rel = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '')
    let filePath = path.join(ROOT, rel)
    if (!filePath.startsWith(ROOT)) return send(res, 403, {}, 'Forbidden')

    let stat = fs.existsSync(filePath) && fs.statSync(filePath)
    if (stat && stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html')
      stat = fs.existsSync(filePath) && fs.statSync(filePath)
    }
    // single-page fallback: unknown non-asset routes -> index.html
    if (!stat) {
      filePath = path.join(ROOT, 'index.html')
      stat = fs.existsSync(filePath) && fs.statSync(filePath)
      if (!stat) return send(res, 404, {}, 'Not found')
    }

    const ext = path.extname(filePath).toLowerCase()
    const immutable = /^\/(assets|fonts|img)\//.test(urlPath)
    const cache =
      ext === '.html'
        ? 'no-cache'
        : immutable
          ? 'public, max-age=31536000, immutable'
          : 'public, max-age=3600'

    const headers = {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': cache,
      'X-Content-Type-Options': 'nosniff',
    }
    if (req.method === 'HEAD') return send(res, 200, headers)
    res.writeHead(200, headers)
    fs.createReadStream(filePath).pipe(res)
  } catch (err) {
    send(res, 500, {}, 'Server error')
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[pynk] serving ${ROOT} at http://${HOST}:${PORT}`)
})
