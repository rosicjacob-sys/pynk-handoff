/* Headless QA driver: renders the real page (rAF alive), scrolls through the
   choreography, exercises the cart, and saves screenshots. */
import puppeteer from 'puppeteer-core'
import { mkdirSync } from 'node:fs'

const OUT = new URL('./shots/', import.meta.url).pathname
mkdirSync(OUT, { recursive: true })

const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new',
  args: ['--hide-scrollbars', '--force-device-scale-factor=1', '--use-angle=metal'],
})

const page = await browser.newPage()
await page.setViewport({ width: 1600, height: 900 })
page.on('console', (m) => {
  const t = m.type()
  if (t === 'error' || t === 'warning') console.log(`[console:${t}]`, m.text())
})
page.on('pageerror', (e) => console.log('[pageerror]', e.message))
page.on('requestfailed', (r) => console.log('[reqfail]', r.url(), r.failure()?.errorText))

await page.goto('http://localhost:5173', { waitUntil: 'networkidle0', timeout: 30000 })
await page.waitForFunction(() => !document.querySelector('.loader'), { timeout: 8000 })
await page.waitForFunction(() => window.__frame && window.__frame.intro >= 1, { timeout: 8000 })
await new Promise((r) => setTimeout(r, 600))
await page.screenshot({ path: OUT + '01-hero.png' })

// helper: lenis-driven scroll then settle
async function go(y, name, settle = 2200) {
  await page.evaluate((yy) => window.__lenis?.scrollTo(yy, { immediate: true }), y)
  await new Promise((r) => setTimeout(r, settle))
  if (name) await page.screenshot({ path: OUT + name })
}

// science pin: start ≈ hero height; sample the scrub beats
const marks = await page.evaluate(() => {
  const ST = window.__ST
  const sci = ST.getAll().find((t) => t.trigger?.id === 'science')
  return { start: sci.start, end: sci.end }
})
const span = marks.end - marks.start
await go(marks.start + span * 0.24, '02-science-split.png')
await go(marks.start + span * 0.5, '03-science-swirl.png')
await go(marks.start + span * 0.8, '04-science-nodes.png')

// how / benefits / proof / buy
const pos = await page.evaluate(() => {
  const y = (id) => document.getElementById(id).getBoundingClientRect().top + (window.__lenis?.scroll ?? scrollY)
  return { how: y('how'), proof: y('proof'), buy: y('buy'), faq: y('faq') }
})
await go(pos.how - 200, '05-how.png')
await go(pos.proof - 250, '06-proof.png', 2600)
await go(pos.buy - 120, '07-buy.png', 2600)

// add to cart: fly + drawer
await page.click('.buy-card .btn--primary')
await new Promise((r) => setTimeout(r, 400))
await page.screenshot({ path: OUT + '08-fly.png' })
await new Promise((r) => setTimeout(r, 1200))
await page.screenshot({ path: OUT + '09-drawer.png' })
const persisted = await page.evaluate(() => localStorage.getItem('pynk-cart-v1'))
console.log('[cart]', persisted)
await page.keyboard.press('Escape')
await new Promise((r) => setTimeout(r, 700))

// sticky bar visible between hero and buy
await go(pos.how + 300, '10-stickybar.png', 1500)

// faq + footer
await go(pos.faq - 100, '11-faq.png', 1500)
await page.evaluate(() => window.__lenis?.scrollTo(document.body.scrollHeight, { immediate: true }))
await new Promise((r) => setTimeout(r, 1500))
await page.screenshot({ path: OUT + '12-footer.png' })

console.log('[stage]', await page.evaluate(() => JSON.stringify(window.__stage)))
await browser.close()
console.log('done')
