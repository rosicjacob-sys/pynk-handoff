import puppeteer from 'puppeteer-core'
const URL = 'https://andreidutescus-macbook-pro.tailb4cf4e.ts.net:8600'
const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new', args: ['--hide-scrollbars','--use-angle=metal'],
})
const page = await browser.newPage()
const errors = []
page.on('console', m => m.type()==='error' && errors.push(m.text()))
page.on('pageerror', e => errors.push('pageerror '+e.message))
page.on('requestfailed', r => errors.push('reqfail '+r.url()))
await page.setViewport({ width: 1440, height: 900 })
await page.goto(URL, { waitUntil: 'networkidle0', timeout: 30000 })
await page.waitForFunction(() => !document.querySelector('.loader'), { timeout: 8000 })
await new Promise(r=>setTimeout(r,1500))
const state = await page.evaluate(() => ({
  title: document.title,
  canvas: !!document.querySelector('.gl-stage canvas'),
  heroText: document.querySelector('.hero__title')?.textContent?.replace(/\s+/g,' ').trim(),
  devHooks: typeof window.__frame, // should be 'undefined' in prod
}))
// add-to-cart over the live link (puppeteer auto-scrolls the button into view)
await page.waitForSelector('.buy-card .btn--primary', { timeout: 8000 })
await page.click('.buy-card .btn--primary')
await new Promise(r=>setTimeout(r,1500))
const cart = await page.evaluate(() => ({
  badge: document.querySelector('.cart-btn__badge')?.textContent,
  drawerOpen: !!document.querySelector('.cart-open'),
  persisted: !!localStorage.getItem('pynk-cart-v1'),
}))
await page.screenshot({ path: 'scripts/shots/link-live.png' })
console.log('[link-render]', JSON.stringify(state))
console.log('[link-cart]', JSON.stringify(cart))
console.log('[link-errors]', errors.length ? errors.slice(0,5) : 'none')
await browser.close()
