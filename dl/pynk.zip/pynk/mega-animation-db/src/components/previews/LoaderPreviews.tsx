import { useRef, useEffect, useState } from 'react'
import gsap from 'gsap'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function BootLoader() {
  const fillRef = useRef<HTMLDivElement>(null)
  const rootRef = useRef<HTMLDivElement>(null)
  const [gone, setGone] = useState(false)

  useEffect(() => {
    if (useReducedMotion()) {
      setGone(true)
      return
    }

    const ctx = gsap.context(() => {
      gsap.to(fillRef.current, {
        scaleX: 1,
        duration: 0.7,
        ease: 'power2.inOut',
      })
    })

    const t = setTimeout(() => {
      gsap.to(rootRef.current, {
        autoAlpha: 0,
        duration: 0.55,
        ease: 'power4.inOut',
        onComplete: () => setGone(true),
      })
    }, 850)

    return () => {
      ctx.revert()
      clearTimeout(t)
    }
  }, [])

  return (
    <div className="preview__center" ref={rootRef}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
        <span
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontSize: '1.4rem',
            fontWeight: 700,
            color: '#1a1a1a',
            letterSpacing: '0.04em',
          }}
        >
          PYNK.
        </span>
        <div
          style={{
            width: 120,
            height: 3,
            background: '#e5e7eb',
            borderRadius: 2,
            overflow: 'hidden',
          }}
        >
          <div
            ref={fillRef}
            style={{
              width: '100%',
              height: '100%',
              background: 'linear-gradient(90deg, #e83e8c, #ff5fa8)',
              borderRadius: 2,
              transformOrigin: 'left',
              transform: 'scaleX(0)',
            }}
          />
        </div>
      </div>
    </div>
  )
}

function NeverBlank() {
  const [elapsed, setElapsed] = useState(0)
  const [revealed, setRevealed] = useState(false)

  useEffect(() => {
    if (useReducedMotion()) {
      setElapsed(3.5)
      setRevealed(true)
      return
    }

    const t0 = performance.now()
    let raf: number
    let done = false

    const tick = (now: number) => {
      const s = (now - t0) / 1000
      setElapsed(Math.min(s, 3.5))
      if (s >= 3.5 && !done) {
        done = true
        setRevealed(true)
      }
      if (s < 4) {
        raf = requestAnimationFrame(tick)
      }
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <div className="preview__center">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '1.5rem',
            fontWeight: 600,
            color: '#6b7280',
          }}
        >
          {elapsed.toFixed(1)}s
        </span>
        {revealed && (
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '0.85rem',
              fontWeight: 600,
              color: '#e83e8c',
            }}
          >
            FORCE REVEAL ✓
          </span>
        )}
      </div>
    </div>
  )
}

export { BootLoader, NeverBlank }
