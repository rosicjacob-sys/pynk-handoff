import { useRef, useEffect, useState } from 'react'
import gsap from 'gsap'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function CustomCursor() {
  const ref = useRef<HTMLDivElement>(null)
  const dotRef = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (useReducedMotion()) return
    if (!ref.current || !dotRef.current || !ringRef.current) return
    if (!window.matchMedia('(pointer: fine)').matches) return

    const dot = dotRef.current
    const ring = ringRef.current
    const container = ref.current
    let dx = 0, dy = 0, rx = 0, ry = 0
    let mx = 0, my = 0

    const onMove = (e: MouseEvent) => {
      const r = container.getBoundingClientRect()
      mx = e.clientX - r.left
      my = e.clientY - r.top
    }

    const onLeave = () => {
      gsap.to([dot, ring], { autoAlpha: 0, duration: 0.15 })
    }
    const onEnter = () => {
      if (window.matchMedia('(pointer: fine)').matches) {
        gsap.to([dot, ring], { autoAlpha: 1, duration: 0.15 })
      }
    }

    const tick = () => {
      dx += (mx - 28 - dx) * 0.4
      dy += (my - 28 - dy) * 0.4
      rx += (mx - 36 - rx) * 0.17
      ry += (my - 36 - ry) * 0.17
      dot.style.transform = `translate(${dx}px, ${dy}px)`
      ring.style.transform = `translate(${rx}px, ${ry}px)`
    }
    gsap.ticker.add(tick)

    container.addEventListener('mousemove', onMove)
    container.addEventListener('mouseleave', onLeave)
    container.addEventListener('mouseenter', onEnter)

    return () => {
      gsap.ticker.remove(tick)
      container.removeEventListener('mousemove', onMove)
      container.removeEventListener('mouseleave', onLeave)
      container.removeEventListener('mouseenter', onEnter)
    }
  }, [])

  return (
    <div
      ref={ref}
      className="preview__center"
      style={{ position: 'relative', cursor: useReducedMotion() ? 'default' : 'none' }}
    >
      <span
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '0.75rem',
          color: '#6b7280',
        }}
      >
        move inside
      </span>
      {!useReducedMotion() && (
        <>
          <div
            ref={dotRef}
            style={{
              position: 'absolute',
              width: 6,
              height: 6,
              borderRadius: '50%',
              background: '#e83e8c',
              pointerEvents: 'none',
              zIndex: 10,
              boxShadow: '0 0 6px rgba(232, 62, 140, 0.6)',
              opacity: 0,
            }}
          />
          <div
            ref={ringRef}
            style={{
              position: 'absolute',
              width: 22,
              height: 22,
              borderRadius: '50%',
              border: '1.5px solid #e83e8c',
              pointerEvents: 'none',
              zIndex: 9,
              boxShadow: '0 0 10px rgba(232, 62, 140, 0.2)',
              opacity: 0,
            }}
          />
        </>
      )}
    </div>
  )
}

export { CustomCursor }
