import { useState, useEffect, useRef } from 'react'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function PillDemo() {
  return (
    <div className="preview__center">
      <div style={{ perspective: 600 }}>
        <div
          className={useReducedMotion() ? '' : 'animate-pill-spin'}
          style={{
            width: 60,
            height: 110,
            borderRadius: 9999,
            background: 'linear-gradient(135deg, #f9a8d4 0%, #e83e8c 40%, #9d174d 100%)',
            boxShadow: '0 0 30px rgba(232, 62, 140, 0.35), inset 0 2px 4px rgba(255,255,255,0.2)',
            position: 'relative',
          }}
        >
          <div
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: 9999,
              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.15) 50%, transparent 100%)',
            }}
          />
        </div>
      </div>
      <div
        style={{
          position: 'absolute',
          width: 120,
          height: 120,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(232,62,140,0.2) 0%, transparent 70%)',
          pointerEvents: 'none',
        }}
      />
    </div>
  )
}

function GranuleDemo() {
  const dots = Array.from({ length: 9 }, (_, i) => ({
    delay: i * 0.7,
    size: 4 + (i % 3) * 2,
    opacity: 0.4 + (i % 3) * 0.2,
    offsetX: (Math.random() - 0.5) * 40,
    offsetY: (Math.random() - 0.5) * 40,
  }))

  return (
    <div className="preview__center" style={{ position: 'relative' }}>
      {dots.map((dot, i) => (
        <div
          key={i}
          className={useReducedMotion() ? '' : 'animate-granule-float'}
          style={{
            position: 'absolute',
            width: dot.size,
            height: dot.size,
            borderRadius: '50%',
            background: `rgba(232, 62, 140, ${dot.opacity})`,
            boxShadow: `0 0 ${dot.size * 2}px rgba(232, 62, 140, 0.3)`,
            animationDelay: `${dot.delay}s`,
            '--ox': `${dot.offsetX}px`,
            '--oy': `${dot.offsetY}px`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  )
}

function BloomDemo() {
  const [pulse, setPulse] = useState(0)

  useEffect(() => {
    if (useReducedMotion()) return
    const interval = setInterval(() => {
      setPulse((p) => (p + 1) % 2)
    }, 1400)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="preview__center">
      <div
        style={{
          width: pulse ? 100 : 70,
          height: pulse ? 100 : 70,
          borderRadius: '50%',
          background: 'radial-gradient(circle, #ff5fa8 0%, #e83e8c 35%, transparent 70%)',
          opacity: pulse ? 0.85 : 0.55,
          transform: `scale(${pulse ? 1.25 : 1})`,
          transition: 'all 1.3s cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      />
    </div>
  )
}

function SplitPill() {
  const [split, setSplit] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setSplit(true)}
      onMouseLeave={() => setSplit(false)}
      style={{ position: 'relative' }}
    >
      <div
        style={{
          width: 50,
          height: 50,
          borderRadius: '50% 50% 0 0',
          background: 'linear-gradient(135deg, #e83e8c, #9d174d)',
          transform: split ? 'translateY(-8px)' : 'translateY(0)',
          transition: 'transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}
      />
      <div
        style={{
          width: 50,
          height: 50,
          borderRadius: '0 0 50% 50%',
          background: 'linear-gradient(135deg, #9d174d, #e83e8c)',
          transform: split ? 'translateY(8px)' : 'translateY(0)',
          transition: 'transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}
      />
    </div>
  )
}

function DissolveDemo() {
  const [dissolved, setDissolved] = useState(false)
  const particles = Array.from({ length: 18 }, (_, i) => ({
    delay: i * 0.03,
    angle: (i / 18) * Math.PI * 2,
    dist: 30 + Math.random() * 40,
    size: 2 + Math.random() * 3,
  }))

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setDissolved(true)}
      onMouseLeave={() => setDissolved(false)}
      style={{ position: 'relative' }}
    >
      {particles.map((p, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            width: p.size,
            height: p.size,
            borderRadius: '50%',
            background: '#e83e8c',
            transform: dissolved
              ? `translate(${Math.cos(p.angle) * p.dist}px, ${Math.sin(p.angle) * p.dist}px)`
              : 'translate(0, 0)',
            opacity: dissolved ? 0 : 0.8,
            transition: `transform 0.7s cubic-bezier(0.4, 0, 0.2, 1) ${p.delay}s, opacity 0.7s ease-out ${p.delay}s`,
          }}
        />
      ))}
    </div>
  )
}

function PerfMonitor() {
  const [fps, setFps] = useState(60)
  const [degraded, setDegraded] = useState(false)

  useEffect(() => {
    if (useReducedMotion()) return

    const cycle = () => {
      setFps(Math.floor(55 + Math.random() * 5))
      if (Math.random() > 0.85) {
        setDegraded(true)
        setTimeout(() => {
          setDegraded(false)
          setFps(60)
        }, 1200)
      }
    }
    const interval = setInterval(cycle, 800)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="preview__center">
      <div
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: '1.8rem',
          fontWeight: 700,
          color: degraded ? '#f59e0b' : '#22c55e',
          transition: 'color 0.3s',
        }}
      >
        {fps}
        <span style={{ fontSize: '0.8rem', marginLeft: 4 }}>fps</span>
      </div>
      {degraded && (
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '0.6rem',
            color: '#f59e0b',
            marginTop: 4,
          }}
        >
          adapting... 30fps
        </span>
      )}
    </div>
  )
}

function StudioLights() {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ position: 'relative', background: '#0d0d0d' }}
    >
      <div
        style={{
          width: 70,
          height: 100,
          borderRadius: 9999,
          background: 'linear-gradient(135deg, #f9a8d4, #e83e8c, #9d174d)',
          position: 'relative',
          zIndex: 2,
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: 70,
          height: 70,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,255,255,0.5) 0%, transparent 70%)',
          top: -10,
          left: hovered ? -15 : -5,
          transition: 'left 0.6s ease-out',
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: 50,
          height: 50,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,233,240,0.4) 0%, transparent 70%)',
          bottom: -5,
          right: hovered ? -10 : 0,
          transition: 'right 0.5s ease-out',
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: 60,
          height: 60,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,95,168,0.4) 0%, transparent 70%)',
          top: 30,
          right: hovered ? -20 : -10,
          transition: 'right 0.7s ease-out',
        }}
      />
    </div>
  )
}

function ErrorBoundary() {
  const [crashed, setCrashed] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setCrashed(true)}
      onMouseLeave={() => setCrashed(false)}
      style={{ position: 'relative' }}
    >
      {!crashed ? (
        <div
          style={{
            width: 60,
            height: 100,
            borderRadius: 9999,
            background: 'linear-gradient(135deg, #f9a8d4, #e83e8c, #9d174d)',
            boxShadow: '0 0 30px rgba(232, 62, 140, 0.3)',
            transition: 'opacity 0.4s',
            opacity: crashed ? 0 : 1,
          }}
        />
      ) : (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 6,
          }}
        >
          <div
            style={{
              width: 60,
              height: 100,
              borderRadius: 9999,
              background: 'linear-gradient(135deg, #cbd5e1, #94a3b8)',
              animation: crashed ? 'none' : undefined,
            }}
          />
          <span
            style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: '0.6rem',
              color: '#22c55e',
              fontWeight: 600,
            }}
          >
            ✓ fallback active
          </span>
        </div>
      )}
    </div>
  )
}

function Lazy3D() {
  const [stage, setStage] = useState<'loading' | 'loaded'>('loading')

  useEffect(() => {
    if (useReducedMotion()) {
      setStage('loaded')
      return
    }
    const t = setTimeout(() => setStage('loaded'), 1000)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="preview__center">
      {stage === 'loading' ? (
        <div
          style={{
            width: 28,
            height: 28,
            border: '2px solid #e5e7eb',
            borderTopColor: '#e83e8c',
            borderRadius: '50%',
            animation: 'spin 0.8s linear infinite',
          }}
        />
      ) : (
        <div style={{ perspective: 600 }}>
          <div
            className={useReducedMotion() ? '' : 'animate-pill-spin'}
            style={{
              width: 50,
              height: 90,
              borderRadius: 9999,
              background: 'linear-gradient(135deg, #f9a8d4, #e83e8c, #9d174d)',
              boxShadow: '0 0 24px rgba(232, 62, 140, 0.3)',
              animation: useReducedMotion() ? 'none' : 'pillSpinner 4s linear infinite',
            }}
          />
        </div>
      )}
    </div>
  )
}

function Hero3D() {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ position: 'relative', perspective: 600 }}
    >
      <div
        style={{
          width: 55,
          height: 95,
          borderRadius: 9999,
          background: 'linear-gradient(135deg, #f9a8d4, #e83e8c, #9d174d)',
          boxShadow: '0 0 30px rgba(232, 62, 140, 0.35)',
          animation: hovered
            ? 'heroTransform 2s ease-in-out infinite'
            : useReducedMotion()
              ? 'none'
              : 'pillFloat 3s ease-in-out infinite',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: 9999,
            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.12) 50%, transparent 100%)',
          }}
        />
      </div>
    </div>
  )
}

function Rotator() {
  return (
    <div className="preview__center" style={{ perspective: 600 }}>
      <div
        style={{
          width: 55,
          height: 95,
          borderRadius: 9999,
          background: 'linear-gradient(135deg, #f9a8d4, #e83e8c, #9d174d)',
          boxShadow: '0 0 24px rgba(232, 62, 140, 0.3)',
          animation: useReducedMotion() ? 'none' : 'rotatorSpin 3s cubic-bezier(0.4, 0, 0.2, 1) infinite',
        }}
      />
    </div>
  )
}

export { PillDemo, GranuleDemo, BloomDemo, SplitPill, DissolveDemo, PerfMonitor, StudioLights, ErrorBoundary, Lazy3D, Hero3D, Rotator }
