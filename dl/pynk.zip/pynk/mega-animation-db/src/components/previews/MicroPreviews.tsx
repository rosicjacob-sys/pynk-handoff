import { useRef, useEffect, useState, useCallback } from 'react'
import gsap from 'gsap'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function MagneticButton() {
  const ref = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) return
    const el = ref.current
    if (!window.matchMedia('(pointer: fine)').matches) return

    const xTo = gsap.quickTo(el, 'x', { duration: 0.35, ease: 'power3.out' })
    const yTo = gsap.quickTo(el, 'y', { duration: 0.35, ease: 'power3.out' })

    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect()
      xTo((e.clientX - (r.left + r.width / 2)) * 0.32)
      yTo((e.clientY - (r.top + r.height / 2)) * 0.32)
    }
    const onLeave = () => {
      gsap.to(el, { x: 0, y: 0, duration: 0.9, ease: 'elastic.out(1, 0.4)' })
    }

    el.addEventListener('mousemove', onMove)
    el.addEventListener('mouseleave', onLeave)
    return () => {
      el.removeEventListener('mousemove', onMove)
      el.removeEventListener('mouseleave', onLeave)
    }
  }, [])

  return (
    <div className="preview__center">
      <button
        ref={ref}
        style={{
          display: 'inline-block',
          fontFamily: "'Inter', sans-serif",
          fontSize: '0.85rem',
          fontWeight: 600,
          color: '#fff',
          background: 'linear-gradient(135deg, #e83e8c, #c0367a)',
          padding: '10px 28px',
          borderRadius: 9999,
          border: 'none',
          cursor: 'pointer',
          boxShadow: '0 2px 12px rgba(232, 62, 140, 0.3)',
          letterSpacing: '0.02em',
        }}
      >
        Shop PYNK
      </button>
    </div>
  )
}

function CountUpDemo() {
  const ref = useRef<HTMLSpanElement>(null)
  const [flash, setFlash] = useState(false)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) {
      ref.current.textContent = '1,250'
      return
    }

    const el = ref.current
    const target = 1250
    const ms = 1400
    const t0 = performance.now()
    let raf: number

    const step = (now: number) => {
      const p = Math.min(1, (now - t0) / ms)
      const eased = 1 - Math.pow(1 - p, 4)
      el.textContent = Math.round(target * eased).toLocaleString('en-US')
      if (p < 1) {
        raf = requestAnimationFrame(step)
      } else {
        el.textContent = target.toLocaleString('en-US')
        setFlash(true)
        setTimeout(() => setFlash(false), 340)
      }
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <div className="preview__center">
      <span
        ref={ref}
        style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          fontSize: '2.6rem',
          fontWeight: 700,
          color: flash ? '#16a34a' : '#1a1a1a',
          transform: flash ? 'scale(1.06)' : 'scale(1)',
          transition: 'color 0.34s ease-out, transform 0.34s ease-out',
        }}
      >
        0
      </span>
    </div>
  )
}

function FlyToCart() {
  const [flying, setFlying] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  const trigger = () => {
    if (flying) return
    setFlying(true)
    setTimeout(() => setFlying(false), 600)
  }

  return (
    <div className="preview__center" style={{ position: 'relative' }} onClick={trigger}>
      <div
        ref={ref}
        style={{
          width: 22,
          height: 22,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #e83e8c, #ff5fa8)',
          boxShadow: '0 0 10px rgba(232, 62, 140, 0.4)',
          position: 'absolute',
          left: flying ? '80%' : '20%',
          top: flying ? '60%' : '30%',
          transform: `scale(${flying ? 0.4 : 1})`,
          opacity: flying ? 0.3 : 1,
          transition: flying
            ? 'left 0.55s cubic-bezier(0.4, 0, 1, 1), top 0.55s cubic-bezier(0.4, 0, 1, 1), transform 0.55s, opacity 0.55s'
            : 'left 0.35s cubic-bezier(0.34, 1.56, 0.64, 1), top 0.35s cubic-bezier(0.34, 1.56, 0.64, 1), transform 0.35s, opacity 0.35s',
        }}
      />
      <span
        style={{
          position: 'absolute',
          right: 16,
          top: 16,
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: '0.65rem',
          color: '#6b7280',
          background: '#f3f4f6',
          padding: '2px 6px',
          borderRadius: 4,
        }}
      >
        cart
      </span>
    </div>
  )
}

function ToastDemo() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 200)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    if (!visible) return
    const t = setTimeout(() => setVisible(false), 2500)
    return () => clearTimeout(t)
  }, [visible])

  return (
    <div className="preview__center">
      <div
        style={{
          transform: visible ? 'translateX(0)' : 'translateX(120%)',
          opacity: visible ? 1 : 0,
          transition: 'transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.35s',
          background: '#1a1a1a',
          color: '#fff',
          padding: '10px 18px',
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontFamily: "'Inter', sans-serif",
          fontSize: '0.82rem',
          fontWeight: 500,
          boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
        }}
      >
        <span style={{ color: '#22c55e', fontSize: '0.9rem' }}>✓</span>
        Added to cart
      </div>
    </div>
  )
}

function StaggerCards() {
  const [hovered, setHovered] = useState(false)
  const cards = ['PYNK Serum', 'PYNK Cream', 'PYNK Oil']

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ display: 'flex', gap: 8 }}
    >
      {cards.map((label, i) => (
        <div
          key={i}
          style={{
            transform: hovered ? 'translateY(0)' : 'translateY(16)',
            opacity: hovered ? 1 : 0,
            transition: `transform 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) ${i * 0.1}s, opacity 0.4s ease-out ${i * 0.1}s`,
            background: '#ffffff',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
            padding: '10px 14px',
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.7rem',
            fontWeight: 600,
            color: '#1a1a1a',
            boxShadow: hovered ? '0 2px 8px rgba(0,0,0,0.06)' : 'none',
          }}
        >
          {label}
        </div>
      ))}
    </div>
  )
}

function GSMCleanup() {
  const [pulsed, setPulsed] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setPulsed(true), 300)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="preview__center">
      <div
        style={{
          background: '#1e1e1e',
          padding: '8px 18px',
          borderRadius: 6,
          transition: 'box-shadow 0.5s ease-out, border-color 0.5s ease-out',
          boxShadow: pulsed ? '0 0 16px rgba(22, 163, 74, 0.5)' : '0 0 0px rgba(22, 163, 74, 0)',
          border: pulsed ? '1px solid #22c55e' : '1px solid #333',
        }}
      >
        <code
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '0.72rem',
            color: pulsed ? '#22c55e' : '#e5e7eb',
            transition: 'color 0.4s',
          }}
        >
          ctx.revert() ✓
        </code>
      </div>
    </div>
  )
}

function OdometerPreview() {
  const ref = useRef<HTMLSpanElement>(null)
  const [flash, setFlash] = useState(false)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) {
      ref.current.textContent = '$12,450'
      return
    }

    const el = ref.current
    const target = 12450
    const ms = 1200
    const t0 = performance.now()
    let raf: number

    const step = (now: number) => {
      const p = Math.min(1, (now - t0) / ms)
      const eased = 1 - Math.pow(1 - p, 4)
      const val = Math.round(target * eased)
      el.textContent = '$' + val.toLocaleString('en-US')
      if (p < 1) {
        raf = requestAnimationFrame(step)
      } else {
        el.textContent = '$' + target.toLocaleString('en-US')
        setFlash(true)
        setTimeout(() => setFlash(false), 340)
      }
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <div className="preview__center">
      <span
        ref={ref}
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: '2.2rem',
          fontWeight: 700,
          color: flash ? '#16a34a' : '#1a1a1a',
          transform: flash ? 'scale(1.06)' : 'scale(1)',
          transition: 'color 0.34s ease-out, transform 0.34s ease-out',
        }}
      >
        $0
      </span>
    </div>
  )
}

export { MagneticButton, CountUpDemo, FlyToCart, ToastDemo, StaggerCards, GSMCleanup, OdometerPreview }
