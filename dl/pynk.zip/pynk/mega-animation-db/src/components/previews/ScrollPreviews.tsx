import { useRef, useEffect, useState } from 'react'
import gsap from 'gsap'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function ProgressRail() {
  const [progress, setProgress] = useState(0)
  const [steps, setSteps] = useState([false, false, false])
  const ref = useRef<HTMLDivElement>(null)

  const onHover = () => {
    if (useReducedMotion()) return
    const ctx = gsap.context(() => {
      gsap.to(ref.current!.querySelector('.pr-fill')!, {
        scaleY: 1,
        duration: 0.8,
        ease: 'power3.inOut',
        onUpdate() {
          const p = this.progress()
          setProgress(p)
          setSteps([p > 0.33, p > 0.66, p > 0.99])
        },
      })
    })
    return () => ctx.revert()
  }

  const onLeave = () => {
    if (useReducedMotion()) return
    gsap.to('.pr-fill', { scaleY: 0, duration: 0.4, ease: 'power2.in' })
    setProgress(0)
    setSteps([false, false, false])
  }

  return (
    <div
      ref={ref}
      className="preview__center"
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      style={{ display: 'flex', gap: 16, alignItems: 'center' }}
    >
      <div
        style={{
          width: 4,
          height: 100,
          background: '#e5e7eb',
          borderRadius: 2,
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <div
          className="pr-fill"
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: 'linear-gradient(to top, #e83e8c, #ff5fa8)',
            borderRadius: 2,
            transformOrigin: 'bottom',
            transform: 'scaleY(0)',
          }}
        />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {['Discover', 'Learn', 'Transform'].map((label, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span
              style={{
                width: 20,
                height: 20,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '0.65rem',
                fontWeight: 700,
                fontFamily: "'Inter', sans-serif",
                background: steps[i] ? '#e83e8c' : '#f3f4f6',
                color: steps[i] ? '#fff' : '#9ca3af',
                transition: 'background 0.3s, color 0.3s',
              }}
            >
              {i + 1}
            </span>
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: '0.72rem',
                fontWeight: steps[i] ? 600 : 400,
                color: steps[i] ? '#1a1a1a' : '#9ca3af',
                transition: 'color 0.3s, font-weight 0.3s',
              }}
            >
              {label}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

function ParallaxImage() {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ overflow: 'hidden', borderRadius: 8 }}
    >
      <div
        style={{
          width: 180,
          height: 100,
          borderRadius: 8,
          background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 30%, #e83e8c 60%, #9d174d 100%)',
          transform: hovered ? 'scale(1.08) translateY(-3px)' : 'scale(1.04) translateY(0)',
          transition: 'transform 1.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        }}
      />
    </div>
  )
}

function TrustMarquee() {
  const logos = ['PYNK', 'GLOW', 'LUXE', 'BLOOM', 'ROSE']
  const repeated = [...logos, ...logos, ...logos]

  return (
    <div
      className="preview__center"
      style={{
        overflow: 'hidden',
        width: '100%',
        maskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)',
      }}
    >
      <div
        style={{
          display: 'flex',
          gap: 24,
          animation: useReducedMotion() ? 'none' : 'marquee-preview 8s linear infinite',
          whiteSpace: 'nowrap',
        }}
      >
        {repeated.map((name, i) => (
          <span
            key={i}
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: '0.9rem',
              fontWeight: 600,
              color: '#9ca3af',
              letterSpacing: '0.04em',
              opacity: 0.6,
            }}
          >
            {name}
          </span>
        ))}
      </div>
    </div>
  )
}

function StickyBar() {
  const [visible, setVisible] = useState(false)

  return (
    <div
      className="preview__center"
      style={{ position: 'relative', overflow: 'hidden', width: '100%', height: '100%' }}
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
    >
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          transform: visible ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
          background: '#1a1a1a',
          padding: '10px 16px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.75rem',
            fontWeight: 600,
            color: '#fff',
          }}
        >
          PYNK Serum · $48
        </span>
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.7rem',
            fontWeight: 600,
            background: '#e83e8c',
            color: '#fff',
            padding: '4px 14px',
            borderRadius: 9999,
          }}
        >
          Buy
        </span>
      </div>
    </div>
  )
}

function NavAdapt() {
  const [dark, setDark] = useState(false)

  return (
    <div
      className="preview__center"
      style={{ width: '100%', height: '100%' }}
      onMouseEnter={() => setDark(true)}
      onMouseLeave={() => setDark(false)}
    >
      <nav
        style={{
          width: '100%',
          padding: '8px 16px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderRadius: 6,
          background: dark ? '#1a1a1a' : '#ffffff',
          border: dark ? '1px solid #333' : '1px solid #e5e7eb',
          transition: 'background 0.3s, border-color 0.3s',
        }}
      >
        <span
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontSize: '0.85rem',
            fontWeight: 700,
            color: dark ? '#fff' : '#1a1a1a',
            transition: 'color 0.3s',
          }}
        >
          PYNK
        </span>
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.7rem',
            color: dark ? '#9ca3af' : '#6b7280',
            transition: 'color 0.3s',
          }}
        >
          {dark ? 'on dark' : 'on light'}
        </span>
      </nav>
    </div>
  )
}

function CardStack() {
  const [hovered, setHovered] = useState(false)
  const items = [
    { icon: '🌿', name: 'Ashwagandha', dose: '300mg' },
    { icon: '🌸', name: 'Rose Hip', dose: '150mg' },
    { icon: '💎', name: 'Collagen', dose: '500mg' },
  ]

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ display: 'flex', gap: 8 }}
    >
      {items.map((item, i) => (
        <div
          key={i}
          style={{
            transform: hovered ? 'translateY(0)' : `translateY(${10 + i * 4}px)`,
            opacity: hovered ? 1 : 0.45 + i * 0.2,
            transition: `transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) ${i * 0.08}s, opacity 0.35s ease-out ${i * 0.08}s`,
            background: '#ffffff',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
            padding: '10px 12px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 4,
          }}
        >
          <span style={{ fontSize: '1.2rem' }}>{item.icon}</span>
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '0.7rem',
              fontWeight: 600,
              color: '#1a1a1a',
            }}
          >
            {item.name}
          </span>
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '0.62rem',
              color: '#e83e8c',
              fontWeight: 500,
            }}
          >
            {item.dose}
          </span>
        </div>
      ))}
    </div>
  )
}

function LenisScroll() {
  const [pos, setPos] = useState(0)
  const animRef = useRef<number>(0)

  useEffect(() => {
    if (useReducedMotion()) return
    const tick = () => {
      setPos((p) => (p + 0.008) % 1)
      animRef.current = requestAnimationFrame(tick)
    }
    animRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  return (
    <div className="preview__center" style={{ width: '100%' }}>
      <div style={{ width: '80%', position: 'relative' }}>
        <div
          style={{
            width: '100%',
            height: 3,
            background: '#e5e7eb',
            borderRadius: 2,
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              width: '20%',
              height: '100%',
              background: 'linear-gradient(90deg, #e83e8c, #ff5fa8)',
              borderRadius: 2,
              transform: `translateX(${pos * 400}%)`,
              boxShadow: '0 0 8px rgba(232, 62, 140, 0.5)',
            }}
          />
        </div>
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '0.6rem',
            color: '#9ca3af',
            marginTop: 6,
            display: 'block',
            textAlign: 'center',
          }}
        >
          smooth scroll
        </span>
      </div>
    </div>
  )
}

function HairlinePreview() {
  const [drawn, setDrawn] = useState(false)

  return (
    <div
      className="preview__center"
      onMouseEnter={() => setDrawn(true)}
      onMouseLeave={() => setDrawn(false)}
      style={{ width: '80%' }}
    >
      <div
        style={{
          width: '100%',
          height: 1,
          background: 'linear-gradient(90deg, transparent, #e83e8c 20%, #e83e8c 80%, transparent)',
          transform: drawn ? 'scaleX(1)' : 'scaleX(0)',
          transformOrigin: 'left',
          transition: 'transform 1.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        }}
      />
    </div>
  )
}

export { ProgressRail, ParallaxImage, TrustMarquee, StickyBar, NavAdapt, CardStack, LenisScroll, HairlinePreview }
