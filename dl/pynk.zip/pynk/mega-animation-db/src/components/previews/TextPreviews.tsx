import { useRef, useEffect, useState } from 'react'
import gsap from 'gsap'
import SplitType from 'split-type'

function useReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

function MaskedCharReveal() {
  const ref = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) return

    const ctx = gsap.context(() => {
      const split = new SplitType(ref.current!, {
        types: 'chars',
        charClass: 'mcr-char',
      })
      gsap.from(split.chars, {
        yPercent: 112,
        duration: 0.8,
        ease: 'power4.out',
        stagger: 0.04,
      })
    })

    return () => ctx.revert()
  }, [])

  return (
    <div className="preview__text-center">
      <h4
        ref={ref}
        style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          fontSize: '1.75rem',
          fontWeight: 700,
          color: '#1a1a1a',
          lineHeight: 1.2,
          letterSpacing: '-0.01em',
        }}
        className="mcr-headline"
      >
        The pink one.
      </h4>
    </div>
  )
}

function KineticType() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) return

    const el = ref.current
    const handler = (e: MouseEvent) => {
      const r = el.getBoundingClientRect()
      const mx = (e.clientX - r.left) / r.width
      const wdth = 100 + mx * 30
      const wght = 400 + Math.abs(mx - 0.5) * 2 * 500
      const skew = (mx - 0.5) * 4
      el.style.fontVariationSettings = `'wdth' ${wdth}, 'wght' ${wght}`
      el.style.transform = `skewX(${skew}deg)`
    }
    el.addEventListener('mousemove', handler)
    return () => el.removeEventListener('mousemove', handler)
  }, [])

  return (
    <div className="preview__text-center" ref={ref} style={{ cursor: 'default' }}>
      <h4
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '1.6rem',
          fontWeight: 700,
          color: '#e83e8c',
          transition: 'font-variation-settings 0.08s ease-out, transform 0.08s ease-out',
          fontVariationSettings: "'wdth' 100, 'wght' 500",
        }}
      >
        move me
      </h4>
    </div>
  )
}

function AccGating() {
  return (
    <div className="preview__text-center">
      <h4
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '1.3rem',
          fontWeight: 600,
          color: '#1a1a1a',
          lineHeight: 1.3,
        }}
      >
        Instant text — no motion
      </h4>
      <span
        style={{
          display: 'inline-block',
          marginTop: 8,
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: '0.7rem',
          color: '#16a34a',
          background: '#dcfce7',
          padding: '3px 10px',
          borderRadius: 4,
          fontWeight: 600,
        }}
      >
        reduced motion ✓
      </span>
    </div>
  )
}

function BlockReveal() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return
    if (useReducedMotion()) return
    const ctx = gsap.context(() => {
      gsap.from(ref.current, {
        y: 26,
        autoAlpha: 0,
        duration: 0.95,
        ease: 'power3.out',
        delay: 0.1,
      })
    })
    return () => ctx.revert()
  }, [])

  return (
    <div className="preview__text-center">
      <div ref={ref} style={{ opacity: 0 }}>
        <h4
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontSize: '1.3rem',
            fontWeight: 600,
            color: '#1a1a1a',
            lineHeight: 1.3,
            marginBottom: 6,
          }}
        >
          PYNK Wellness
        </h4>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '0.8rem',
            color: '#6b7280',
            maxWidth: 260,
            margin: '0 auto',
          }}
        >
          Clean y+fade block entrance with subtle downward slide.
        </p>
      </div>
    </div>
  )
}

function FaqAccordion() {
  const [open, setOpen] = useState(0)
  const items = [
    { q: 'What is PYNK?', a: 'A premium wellness brand.' },
    { q: 'How does it work?', a: 'Clinically tested ingredients.' },
  ]

  return (
    <div style={{ width: '100%', padding: '12px 16px' }}>
      {items.map((item, i) => (
        <div key={i} style={{ marginBottom: 6 }}>
          <button
            onClick={() => setOpen(open === i ? -1 : i)}
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 10px',
              border: '1px solid #e5e7eb',
              borderRadius: 6,
              background: open === i ? '#fdf2f8' : '#ffffff',
              cursor: 'pointer',
              fontFamily: "'Inter', sans-serif",
              fontSize: '0.78rem',
              fontWeight: 500,
              color: '#1a1a1a',
              transition: 'background 0.2s',
            }}
          >
            {item.q}
            <span style={{ transform: open === i ? 'rotate(45deg)' : 'none', transition: 'transform 0.3s' }}>
              +
            </span>
          </button>
          <div
            style={{
              height: open === i ? 'auto' : 0,
              overflow: 'hidden',
              transition: 'height 0.35s cubic-bezier(0.76, 0, 0.24, 1)',
            }}
          >
            <p
              style={{
                padding: '6px 10px',
                fontSize: '0.72rem',
                color: '#6b7280',
                fontFamily: "'Inter', sans-serif",
              }}
            >
              {item.a}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

export { MaskedCharReveal, KineticType, AccGating, BlockReveal, FaqAccordion }
