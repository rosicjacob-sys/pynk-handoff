import { useEffect, useState, useRef } from 'react'
import gsap from 'gsap'
import {
  MaskedCharReveal,
  KineticType,
  AccGating,
  BlockReveal,
  FaqAccordion,
} from './previews/TextPreviews'
import {
  MagneticButton,
  CountUpDemo,
  FlyToCart,
  ToastDemo,
  StaggerCards,
  GSMCleanup,
  OdometerPreview,
} from './previews/MicroPreviews'
import {
  ProgressRail,
  ParallaxImage,
  TrustMarquee,
  StickyBar,
  NavAdapt,
  CardStack,
  LenisScroll,
  HairlinePreview,
} from './previews/ScrollPreviews'
import {
  PillDemo,
  GranuleDemo,
  BloomDemo,
  SplitPill,
  DissolveDemo,
  PerfMonitor,
  StudioLights,
  ErrorBoundary,
  Lazy3D,
  Hero3D,
  Rotator,
} from './previews/WebGLPreviews'
import { CustomCursor } from './previews/CursorPreviews'
import { BootLoader, NeverBlank } from './previews/LoaderPreviews'

interface Props {
  animationId: string
  previewType: string
}

const componentMap: Record<string, React.FC> = {
  'ani-001': MaskedCharReveal,
  'ani-002': BlockReveal,
  'ani-003': MagneticButton,
  'ani-004': CustomCursor,
  'ani-005': CountUpDemo,
  'ani-006': PillDemo,
  'ani-007': GranuleDemo,
  'ani-008': BootLoader,
  'ani-009': ProgressRail,
  'ani-010': KineticType,
  'ani-011': BloomDemo,
  'ani-012': NavAdapt,
  'ani-013': PerfMonitor,
  'ani-014': LenisScroll,
  'ani-015': NeverBlank,
  'ani-016': Hero3D,
  'ani-017': StaggerCards,
  'ani-018': TrustMarquee,
  'ani-019': FaqAccordion,
  'ani-020': Rotator,
  'ani-021': StickyBar,
  'ani-022': FlyToCart,
  'ani-023': ParallaxImage,
  'ani-024': StudioLights,
  'ani-025': OdometerPreview,
  'ani-026': HairlinePreview,
  'ani-027': SplitPill,
  'ani-028': DissolveDemo,
  'ani-029': ErrorBoundary,
  'ani-030': ToastDemo,
  'ani-031': CardStack,
  'ani-032': Lazy3D,
  'ani-033': GSMCleanup,
  'ani-034': AccGating,
}

const PREVIEW_COLORS: Record<string, string> = {
  text: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
  scroll: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)',
  webgl: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)',
  cursor: 'linear-gradient(135deg, #fefce8 0%, #fef9c3 100%)',
  micro: 'linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%)',
  loader: 'linear-gradient(135deg, #f5f3ff 0%, #ede9fe 100%)',
}

export default function PreviewRenderer({ animationId, previewType }: Props) {
  const [inView, setInView] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const Comp = componentMap[animationId]

  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          io.disconnect()
        }
      },
      { threshold: 0.1 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  const bgColor = PREVIEW_COLORS[previewType] || PREVIEW_COLORS.micro
  const isDark = previewType === 'webgl'

  return (
    <div
      ref={containerRef}
      style={{
        height: '100%',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
        background: bgColor,
        color: isDark ? '#fff' : undefined,
      }}
    >
      {inView && Comp ? (
        <Comp />
      ) : (
        <div style={{ width: '100%', height: '100%' }} />
      )}
    </div>
  )
}
