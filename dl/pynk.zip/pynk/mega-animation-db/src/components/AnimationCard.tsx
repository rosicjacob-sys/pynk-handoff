import { useState } from 'react'
import { ThumbsUp, ThumbsDown, X } from 'lucide-react'
import { usePreferences } from '../store/preferences'
import type { AnimationEntry } from '../data/animations'
import PreviewRenderer from './PreviewRenderer'

interface Props {
  animation: AnimationEntry
}

const PREVIEW_LABELS: Record<string, string> = {
  text: 'Text Reveal',
  scroll: 'Scroll Animation',
  webgl: '3D / WebGL',
  cursor: 'Cursor Effect',
  micro: 'Micro-interaction',
  loader: 'Loader / Boot',
}

export default function AnimationCard({ animation }: Props) {
  const vote = usePreferences((s) => s.getVote(animation.id))
  const setVote = usePreferences((s) => s.setVote)
  const [showModal, setShowModal] = useState(false)

  return (
    <>
      <article className="anim-card" onClick={() => setShowModal(true)}>
        <div className={`anim-card__preview anim-card__preview--${animation.previewType}`}>
          <span className="anim-card__code">{animation.code}</span>
          <PreviewRenderer animationId={animation.id} previewType={animation.previewType} />
        </div>
        <div className="anim-card__body">
          <h3 className="anim-card__title">{animation.title}</h3>
          <p className="anim-card__desc">{animation.description}</p>
          <div className="anim-card__tags">
            <span className={`complexity complexity--${animation.complexity}`}>
              {animation.complexity}
            </span>
            {animation.tags.slice(0, 2).map((tag) => (
              <span key={tag} className="anim-card__tag">{tag}</span>
            ))}
            {animation.tags.length > 2 && (
              <span className="anim-card__tag">+{animation.tags.length - 2}</span>
            )}
          </div>
          <div className="anim-card__actions" onClick={(e) => e.stopPropagation()}>
            <button
              className={`btn-approve ${vote === 'approve' ? 'btn-approve--active' : ''}`}
              onClick={() => setVote(animation.id, vote === 'approve' ? null : 'approve')}
            >
              <ThumbsUp size={14} />
              Like
            </button>
            <button
              className={`btn-decline ${vote === 'decline' ? 'btn-decline--active' : ''}`}
              onClick={() => setVote(animation.id, vote === 'decline' ? null : 'decline')}
            >
              <ThumbsDown size={14} />
              Pass
            </button>
          </div>
        </div>
      </article>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div
              style={{
                display: 'flex',
                justifyContent: 'flex-end',
                padding: '12px 16px 0',
              }}
            >
              <button
                onClick={() => setShowModal(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: 'var(--color-text-muted)',
                  padding: 4,
                  borderRadius: 6,
                  display: 'flex',
                }}
              >
                <X size={18} />
              </button>
            </div>
            <div className={`modal__preview modal__preview--${animation.previewType}`}>
              <PreviewRenderer animationId={animation.id} previewType={animation.previewType} />
            </div>
            <div className="modal__body">
              <span className="modal__code">{animation.code}</span>
              <h2 className="modal__title">{animation.title}</h2>
              <p className="modal__desc">{animation.longDescription}</p>
              <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
                <span className={`complexity complexity--${animation.complexity}`}>
                  {animation.complexity}
                </span>
                <span className="anim-card__tag">{animation.niche}</span>
                <span className="anim-card__tag">{animation.category}</span>
                <span className="anim-card__tag">{PREVIEW_LABELS[animation.previewType]}</span>
              </div>
              {animation.tags.length > 0 && (
                <>
                  <div className="modal__section-title">Tags</div>
                  <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 16 }}>
                    {animation.tags.map((tag) => (
                      <span key={tag} className="anim-card__tag">{tag}</span>
                    ))}
                  </div>
                </>
              )}
              <div className="modal__section-title">
                Source Pattern · {animation.patternRef}
              </div>
              <pre className="modal__code-block">
                <code>{animation.codeSnippet}</code>
              </pre>
              <div className="modal__actions">
                <button
                  className={`btn-approve ${vote === 'approve' ? 'btn-approve--active' : ''}`}
                  onClick={() => setVote(animation.id, vote === 'approve' ? null : 'approve')}
                >
                  <ThumbsUp size={16} />
                  {vote === 'approve' ? 'Approved' : 'Approve'}
                </button>
                <button
                  className={`btn-decline ${vote === 'decline' ? 'btn-decline--active' : ''}`}
                  onClick={() => setVote(animation.id, vote === 'decline' ? null : 'decline')}
                >
                  <ThumbsDown size={16} />
                  {vote === 'decline' ? 'Declined' : 'Decline'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
