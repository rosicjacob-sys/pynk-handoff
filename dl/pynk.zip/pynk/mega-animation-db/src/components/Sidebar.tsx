import { NICHES, CATEGORIES } from '../data/animations'

interface Props {
  activeNiche: string
  onNicheChange: (id: string) => void
  activeCategory: string
  onCategoryChange: (id: string) => void
}

export default function Sidebar({
  activeNiche,
  onNicheChange,
  activeCategory,
  onCategoryChange,
}: Props) {
  return (
    <aside className="sidebar">
      <div className="sidebar__brand">
        <div className="sidebar__brand-dot" />
        Motion DB
      </div>
      <nav className="sidebar__nav">
        <div className="sidebar__section-label">Niches</div>
        {NICHES.map((niche) => (
          <button
            key={niche.id}
            className={`sidebar__item ${activeNiche === niche.id ? 'sidebar__item--active' : ''}`}
            onClick={() => onNicheChange(niche.id)}
          >
            <span>{niche.icon}</span>
            <span>{niche.label}</span>
          </button>
        ))}
        <div className="sidebar__section-label">Categories</div>
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            className={`sidebar__item ${activeCategory === cat.id ? 'sidebar__item--active' : ''}`}
            onClick={() => onCategoryChange(cat.id)}
          >
            <span>{cat.label}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar__footer">
        <span className="sidebar__footer-stat">34 patterns</span>
        <span className="sidebar__footer-stat">v1.0</span>
      </div>
    </aside>
  )
}
