import { Search, SlidersHorizontal, CheckCircle2, XCircle } from 'lucide-react'
import { usePreferences } from '../store/preferences'

interface Props {
  searchQuery: string
  onSearchChange: (q: string) => void
  totalCount: number
  activeNiche: string
}

export default function Header({ searchQuery, onSearchChange, totalCount, activeNiche }: Props) {
  const votes = usePreferences((s) => s.votes)
  const approvedCount = Object.values(votes).filter((v) => v === 'approve').length
  const declinedCount = Object.values(votes).filter((v) => v === 'decline').length

  return (
    <header className="header">
      <span className="header__title">{activeNiche}</span>
      <div className="header__search">
        <Search size={16} style={{ color: 'var(--color-text-muted)', flexShrink: 0 }} />
        <input
          type="text"
          placeholder="Search by title, code, tag, or description..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--color-text-muted)',
              fontSize: '0.8rem',
              padding: '0 4px',
            }}
          >
            ✕
          </button>
        )}
      </div>
      <div className="header__actions">
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
          <CheckCircle2 size={14} style={{ color: '#16a34a' }} />
          <span style={{ fontWeight: 500, color: '#16a34a' }}>{approvedCount}</span>
          <span style={{ margin: '0 2px' }}>/</span>
          <XCircle size={14} style={{ color: '#dc2626' }} />
          <span style={{ fontWeight: 500, color: '#dc2626' }}>{declinedCount}</span>
          <span style={{ marginLeft: 6, opacity: 0.5 }}>showing {totalCount}</span>
        </div>
      </div>
    </header>
  )
}
