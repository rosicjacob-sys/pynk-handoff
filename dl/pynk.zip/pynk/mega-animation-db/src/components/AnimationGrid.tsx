import { PackageOpen } from 'lucide-react'
import AnimationCard from './AnimationCard'
import type { AnimationEntry } from '../data/animations'

interface Props {
  animations: AnimationEntry[]
  selected: AnimationEntry | null
  onSelect: (anim: AnimationEntry | null) => void
}

export default function AnimationGrid({ animations }: Props) {
  if (animations.length === 0) {
    return (
      <div className="empty-state">
        <PackageOpen size={48} className="empty-state__icon" />
        <h3 className="empty-state__title">No animations found</h3>
        <p className="empty-state__desc">
          Try adjusting your search or filters. The database grows as you curate your preferences.
        </p>
      </div>
    )
  }

  return (
    <div className="anim-grid">
      {animations.map((anim) => (
        <AnimationCard key={anim.id} animation={anim} />
      ))}
    </div>
  )
}
