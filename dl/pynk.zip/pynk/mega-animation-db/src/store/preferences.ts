import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type Vote = 'approve' | 'decline' | null

interface PreferencesState {
  votes: Record<string, Vote>
  likedNiches: Record<string, number>
  dislikedNiches: Record<string, number>
  setVote: (animationId: string, vote: Vote) => void
  getVote: (animationId: string) => Vote
}

export const usePreferences = create<PreferencesState>()(
  persist(
    (set, get) => ({
      votes: {},
      likedNiches: {},
      dislikedNiches: {},
      setVote: (animationId: string, vote: Vote) => {
        set((state) => {
          const newVotes = { ...state.votes }
          if (vote === null) {
            delete newVotes[animationId]
          } else {
            newVotes[animationId] = vote
          }
          return { votes: newVotes }
        })
      },
      getVote: (animationId: string) => get().votes[animationId] ?? null,
    }),
    {
      name: 'mega-animation-db-prefs',
    },
  ),
)
