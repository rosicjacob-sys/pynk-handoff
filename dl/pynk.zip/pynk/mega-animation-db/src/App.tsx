import { useState, useMemo } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import AnimationGrid from './components/AnimationGrid'
import { animations, NICHES, CATEGORIES } from './data/animations'
import type { AnimationEntry } from './data/animations'

export default function App() {
  const [activeNiche, setActiveNiche] = useState('all')
  const [activeCategory, setActiveCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedAnim, setSelectedAnim] = useState<AnimationEntry | null>(null)

  const filteredAnimations = useMemo(() => {
    return animations.filter((anim) => {
      const matchesNiche = activeNiche === 'all' || anim.nicheId === activeNiche
      const matchesCategory = activeCategory === 'all' || anim.categoryId === activeCategory
      const matchesSearch =
        !searchQuery ||
        anim.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        anim.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        anim.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
        anim.description.toLowerCase().includes(searchQuery.toLowerCase())
      return matchesNiche && matchesCategory && matchesSearch
    })
  }, [activeNiche, activeCategory, searchQuery])

  return (
    <div className="app-layout">
      <Sidebar
        activeNiche={activeNiche}
        onNicheChange={setActiveNiche}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />
      <div className="main-content">
        <Header
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          totalCount={filteredAnimations.length}
          activeNiche={NICHES.find((n) => n.id === activeNiche)?.label ?? 'All Animations'}
        />
        <AnimationGrid
          animations={filteredAnimations}
          selected={selectedAnim}
          onSelect={setSelectedAnim}
        />
      </div>
    </div>
  )
}
