#!/usr/bin/env node
const http = require('http')
const fs = require('fs')
const path = require('path')

const ROOT = path.join(__dirname, '..', 'dist')
const PORT = Number(process.env.PORT || 8500)
const HOST = '127.0.0.1'

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.woff2': 'font/woff2',
  '.svg': 'image/svg+xml',
}

function send(res, status, headers, body) {
  res.writeHead(status, headers)
  if (body) res.end(body)
  else res.end()
}

const server = http.createServer((req, res) => {
  try {
    let rel = path.normalize(decodeURIComponent((req.url || '/').split('?')[0]))
    rel = rel.replace(/^(\.\.[/\\])+/, '')
    let filePath = path.join(ROOT, rel)
    if (!filePath.startsWith(ROOT)) return send(res, 403, {}, 'Forbidden')

    let stat = fs.existsSync(filePath) && fs.statSync(filePath)
    if (stat && stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html')
      stat = fs.existsSync(filePath) && fs.statSync(filePath)
    }
    if (!stat) {
      filePath = path.join(ROOT, 'index.html')
      stat = fs.existsSync(filePath) && fs.statSync(filePath)
      if (!stat) return send(res, 404, {}, 'Not found')
    }

    const ext = path.extname(filePath).toLowerCase()
    const headers = {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    }
    if (req.method === 'HEAD') return send(res, 200, headers)
    res.writeHead(200, headers)
    fs.createReadStream(filePath).pipe(res)
  } catch {
    send(res, 500, {}, 'Server error')
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[motion-db] serving ${ROOT} at http://${HOST}:${PORT}`)
})
