# PYNK — Take the pink one.

A single-page, scroll-choreographed 3D e-commerce landing page for a (fictional)
pink daily supplement. One persistent WebGL capsule threads the whole page:
floats in the hero → cracks open into a granule swirl that locks into labeled
ingredient nodes (dark, pinned "Science" scrub) → granules stream down and
re-form the pill ("How it works") → the pill multiplies into a ghosted parallax
wall ("Proof") → everything converges onto the product bottle ("Buy").

## Stack

- React 18 + Vite + TypeScript
- three / @react-three/fiber / @react-three/drei (one persistent canvas, custom GLSL granules)
- GSAP + ScrollTrigger (free plugins only) + split-type masked reveals
- Lenis smooth scroll, driven from the GSAP ticker
- zustand cart (localStorage persistence), swappable `checkout()` adapter

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build && npx vite preview
```

## Commerce wiring

`src/lib/checkout.ts` exposes `setCheckoutProvider(adapter)` — plug in Shopify
Storefront, Stripe Checkout or Snipcart without touching UI code. Analytics
stubs push `view_item`, `add_to_cart`, `begin_checkout` to `window.dataLayer`.

## Robustness contract

- `prefers-reduced-motion`: no canvas, no Lenis, no scrubs, no flying pill — static, buyable page.
- WebGL unavailable / context lost / scene crash → static CSS pill fallback (`glsignal`).
- Every reveal has a 3.5s wall-clock failsafe; the boot loader is hard-capped (backgrounded-tab safe).
- One WebGL context for the page; DPR clamped [1,2]; PerformanceMonitor steps DPR + live
  granule count down under sustained load; all geometries/materials disposed on unmount.

## QA harness

`scripts/qa.mjs` and `scripts/qa2.mjs` drive the real page headless (puppeteer-core +
installed Chrome): scroll the full choreography, screenshot every beat into
`scripts/shots/`, exercise add-to-cart/drawer/persistence, measure scrub fps, and
run mobile / reduced-motion / WebGL-off passes.

Verified: Lighthouse (mobile emulation) **99 performance / 100 accessibility /
100 best practices**, LCP 2.0s, CLS 0, zero console errors.

## Deploy

`vercel.json` ships HTML with `Cache-Control: no-cache` and hashed assets as
immutable, so a redeploy can never serve a stale index against new chunks.
Any static host works — mirror those two header rules.

## Compliance

Structure/function claims only; FDA disclaimer in the Science section, FAQ
compliance note, Supplement Facts panel and footer. Demo store — no real
product, reviews are illustrative copy.

## Hosted preview (Tailscale)

The production build is served to the tailnet on a dedicated port:

- **Link:** `https://andreidutescus-macbook-pro.tailb4cf4e.ts.net:8600/` (tailnet only)
- **Static server:** [scripts/serve-dist.cjs](scripts/serve-dist.cjs) serves `dist/` on `127.0.0.1:8899` with the deploy cache contract (HTML `no-cache`, hashed assets immutable).
- **Durability:** a user LaunchAgent (`~/Library/LaunchAgents/com.pynk.preview.plist`) runs it with `RunAtLoad`+`KeepAlive`, so it survives logout/reboot.
- **Tailscale mapping:** `tailscale serve --bg --https=8600 http://127.0.0.1:8899`.

Manage it:

```bash
# after code changes — rebuild, then the same URL serves the new bundle
npm run build

# restart the static server (picks up a fresh dist)
launchctl kickstart -k gui/$(id -u)/com.pynk.preview

# take the link down entirely
/Applications/Tailscale.app/Contents/MacOS/Tailscale serve --https=8600 off
launchctl bootout gui/$(id -u)/com.pynk.preview
```

To make it public on the internet instead of tailnet-only, Funnel is required —
but this machine already uses all three Funnel ports (443, 8443, 10000), so it
would mean sharing port 443 behind a unique path rather than a dedicated port.
